package main;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class urediUsmjerenjeController {
    @FXML
    private TextField etSifUsmjerenje;
    @FXML
    private TextField etNazivUsmjerenje;
    @FXML
    private TableView<Usmjerenje> tableUsmjerenja;

    private Usmjerenje selectedUsmjerenje;
    private int selectedIndex;
    private ObservableList<Usmjerenje> listUsmjerenja;


    public void recieveInfoFromUsmjerenja(Usmjerenje usmjerenje, int index, ObservableList<Usmjerenje> list, TableView<Usmjerenje> table){
        selectedUsmjerenje = usmjerenje;
        selectedIndex = index;
        listUsmjerenja = list;
        tableUsmjerenja = table;
        etSifUsmjerenje.setText(selectedUsmjerenje.getSifraUsmjerenje());
        etNazivUsmjerenje.setText(selectedUsmjerenje.getNazivUsmjerenje());
    }

    public void sacuvajClicked(){
        String sifUsmjerenje = etSifUsmjerenje.getText();
        String nazivUsmjerenje = etNazivUsmjerenje.getText();

        for(Usmjerenje e : listUsmjerenja){
            if(sifUsmjerenje.compareTo(e.getSifraUsmjerenje())==0 && nazivUsmjerenje.compareTo(e.getNazivUsmjerenje())==0){
                DBConnector.showAlert("Usmjerenja","Usmjerenje vec postoji!");
                return;
            }
        }
        try{
            Connection conn = DBConnector.getConnection();
            String query = "UPDATE usmjerenje SET sifraUsmjerenje = ?, nazivUsmjerenje = ? WHERE idUsmjerenje = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, sifUsmjerenje);
            ps.setString(2,nazivUsmjerenje);
            ps.setInt(3,selectedUsmjerenje.getIdUsmjerenje());
            if(ps.executeUpdate()>0) {
                DBConnector.showAlert("Usmjerenja", "Sacuvano!");
                conn.close();
                selectedUsmjerenje.setSifraUsmjerenje(sifUsmjerenje);
                selectedUsmjerenje.setNazivUsmjerenje(nazivUsmjerenje);
                listUsmjerenja.set(selectedIndex,selectedUsmjerenje);
                Stage stage = (Stage) etSifUsmjerenje.getScene().getWindow();
                stage.close();
                tableUsmjerenja.refresh();
            }
            else{
                DBConnector.showAlert("Usmjerenje", "Greska!");
            }

        }

        catch (Exception e) {
            e.printStackTrace();
        }

    }
}
