package main;

public class Korisnik {

    private Integer idKorisnik;
    private String korIme, korSifra, imeKorisnik, prezKorisnik;
    private Boolean prodekan, profesor, saradnik;

    public Korisnik(){}

    public Korisnik(Integer idKorisnik, String korIme, String korSifra, String imeKorisnik, String prezKorisnik, Boolean prodekan, Boolean profesor, Boolean saradnik){
        this.idKorisnik = idKorisnik;
        this.korIme = korIme;
        this.korSifra = korSifra;
        this.imeKorisnik = imeKorisnik;
        this.prezKorisnik = prezKorisnik;
        this.prodekan = prodekan;
        this.profesor = profesor;
        this.saradnik = saradnik;
    }

    public int getIdKorisnik() {
        return idKorisnik;
    }

    public void setIdKorisnik(int idKorisnik) {
        this.idKorisnik = idKorisnik;
    }

    public String getKorIme() {
        return korIme;
    }

    public void setKorIme(String korIme) {
        this.korIme = korIme;
    }

    public String getKorSifra() {
        return korSifra;
    }

    public void setKorSifra(String korSifra) {
        this.korSifra = korSifra;
    }

    public String getImeKorisnik() {
        return imeKorisnik;
    }

    public void setImeKorisnik(String imeKorisnik) {
        this.imeKorisnik = imeKorisnik;
    }

    public String getPrezKorisnik() {
        return prezKorisnik;
    }

    public void setPrezKorisnik(String prezKorisnik) {
        this.prezKorisnik = prezKorisnik;
    }

    public boolean isProdekan() {
        return prodekan;
    }

    public void setProdekan(boolean prodekan) {
        this.prodekan = prodekan;
    }

    public boolean isProfesor() {
        return profesor;
    }

    public void setProfesor(boolean profesor) {
        this.profesor = profesor;
    }

    public boolean isSaradnik() {
        return saradnik;
    }

    public void setSaradnik(boolean saradnik) {
        this.saradnik = saradnik;
    }


    @Override
    public String toString() {
        return imeKorisnik + " " + prezKorisnik;
    }
}
