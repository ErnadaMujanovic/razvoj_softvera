package main;

public class Semestar {
    private Integer idSemestar;
    private String pocetak, kraj, nazivSemestar;

    public Semestar(){}

    public Semestar(int idSemestar, String pocetak, String kraj, String nazivSemestar){
        this.idSemestar = idSemestar;
        this.pocetak = pocetak;
        this.kraj = kraj;
        this.nazivSemestar = nazivSemestar;
    }

    public int getIdSemestar() {
        return idSemestar;
    }

    public void setIdSemestar(int idSemestar) {
        this.idSemestar = idSemestar;
    }

    public String getPocetak() {
        return pocetak;
    }

    public void setPocetak(String pocetak) {
        this.pocetak = pocetak;
    }

    public String getKraj() {
        return kraj;
    }

    public void setKraj(String kraj) {
        this.kraj = kraj;
    }

    public String getNazivSemestar() {
        return nazivSemestar;
    }

    public void setNazivSemestar(String nazivSemestar) {
        this.nazivSemestar = nazivSemestar;
    }

    @Override
    public String toString() {
        return nazivSemestar;
    }
}
