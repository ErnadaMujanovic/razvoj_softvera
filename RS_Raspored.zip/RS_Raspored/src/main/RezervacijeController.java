package main;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.ResourceBundle;

public class RezervacijeController implements Initializable {

    private Korisnik korisnik;

    @FXML
    private TableView<Rezervacija> tableRezervacije;
    @FXML
    private TableColumn<Rezervacija, String> colNastavnik;
    @FXML
    private TableColumn<Rezervacija, String> colGrupa;
    @FXML
    private TableColumn<Rezervacija, String> colSala;
    @FXML
    private TableColumn<Rezervacija, String> colDatum;
    @FXML
    private TableColumn<Rezervacija, String> colPocetak;
    @FXML
    private TableColumn<Rezervacija, String> colkraj;
    @FXML
    private TableColumn<Rezervacija, String> colTip;
    @FXML
    private TableColumn<Rezervacija, String> colDan;

    @FXML
    private TableView<Korisnik> tableNastavnici;
    @FXML
    private TableColumn<Korisnik, String> colIme;
    @FXML
    private TableColumn<Korisnik, String> colPrezime;

    @FXML
    private ListView<Grupa> lvGrupe;
    @FXML
    private ComboBox<Sala> cbSale;
    @FXML
    private ComboBox<String> cbTip;
    @FXML
    private ComboBox<Integer> cbSatiPocetak;
    @FXML
    private ComboBox<Integer> cbSatiKraj;
    @FXML
    private ComboBox<String> cbDan;
    @FXML
    private DatePicker dpDatum;
    @FXML
    private TextField etPretraziNastavnike;
    @FXML
    private TextField etPretraziRezervacije;
    @FXML
    private Button btnPretraziNastavnike;
    @FXML
    private Label lblGrupa;

    ObservableList<Rezervacija> listRezervacije = FXCollections.observableArrayList();
    ObservableList<Rezervacija> listTrazeneRezervacije = FXCollections.observableArrayList();
    ObservableList<Korisnik> listNastavnici = FXCollections.observableArrayList();
    ObservableList<Korisnik> listTrazeniNastavnici = FXCollections.observableArrayList();
    ObservableList<Grupa> listGrupe = FXCollections.observableArrayList();
    ObservableList<Sala> listSale = FXCollections.observableArrayList();
    ObservableList<String> listTip = FXCollections.observableArrayList();
    ObservableList<Integer> listSati = FXCollections.observableArrayList();
    ObservableList<Rezervacija> listNstavnikRezervacije = FXCollections.observableArrayList();
    ObservableList<String> listDani = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        listTip.add("nadoknada");listTip.add("seminar");listTip.add("simpozij");listTip.add("diplomski");listTip.add("magistarski");listTip.add("doktorat");
        cbTip.setItems(listTip);

        listDani.add("ponedjeljak");listDani.add("utorak");listDani.add("srijeda");listDani.add("cetvrtak");listDani.add("petak");listDani.add("subota");
        cbDan.setItems(listDani);

        for(Integer i = 8;i<21;++i){
            listSati.add((Integer)i);
        }
        cbSatiPocetak.setItems(listSati);
        cbSatiKraj.setItems(listSati);



        try{
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM rezervacija INNER JOIN sala ON rezervacija.idSala = sala.idSala INNER JOIN " +
                    "korisnik ON rezervacija.idKorisnik = korisnik.idKorisnik  LEFT JOIN grupa ON rezervacija.idGrupa = grupa.idGrupa ORDER BY idRezervacija");
            while (rs.next()) {
                Sala sala = new Sala(rs.getInt("idSala"),null,rs.getString("sifraSala"));
                Korisnik nastavnik = new Korisnik(rs.getInt("idKorisnik"), rs.getString("korIme"),  rs.getString("korSifra"),
                        rs.getString("imeKorisnik"), rs.getString("prezKorisnik"),rs.getBoolean("prodekan"),rs.getBoolean("profesor"),
                        rs.getBoolean("saradnik"));

                Grupa grupa = new Grupa(rs.getInt("idGrupa"),null,null,rs.getString("sifraGrupa"),rs.getString("vrsta"));
                listRezervacije.add(new Rezervacija(rs.getInt("idRezervacija"),rs.getDate("datum"),rs.getTime("pocetak")
                        ,rs.getTime("kraj"),rs.getString("tip"),sala,nastavnik,grupa,rs.getString("dan")));
            }
            rs.close();

            colNastavnik.setCellValueFactory(new PropertyValueFactory<>("korisnik"));
            colGrupa.setCellValueFactory(new PropertyValueFactory<>("grupa"));
            colSala.setCellValueFactory(new PropertyValueFactory<>("sala"));
            colDatum.setCellValueFactory(new PropertyValueFactory<>("datum"));
            colPocetak.setCellValueFactory(new PropertyValueFactory<>("pocetak"));
            colkraj.setCellValueFactory(new PropertyValueFactory<>("kraj"));
            colTip.setCellValueFactory(new PropertyValueFactory<>("tip"));
            colDan.setCellValueFactory(new PropertyValueFactory<>("dan"));
            tableRezervacije.setItems(listRezervacije);

            //===================================Nastavnici==============================================
            rs = conn.createStatement().executeQuery("SELECT DISTINCT * FROM korisnik ORDER BY idKorisnik");
            while (rs.next()) {
                listNastavnici.add(new Korisnik(rs.getInt("idKorisnik"), rs.getString("korIme"),  rs.getString("korSifra"),
                        rs.getString("imeKorisnik"), rs.getString("prezKorisnik"),rs.getBoolean("prodekan"),rs.getBoolean("profesor"),
                        rs.getBoolean("saradnik")));
            }
            colIme.setCellValueFactory(new PropertyValueFactory<>("imeKorisnik"));
            colPrezime.setCellValueFactory(new PropertyValueFactory<>("prezKorisnik"));
            tableNastavnici.setItems(listNastavnici);
            //===================================Sale==============================================
            rs = conn.createStatement().executeQuery("SELECT DISTINCT * FROM sala ORDER BY idSala");
            while (rs.next()) {
                listSale.add(new Sala(rs.getInt("idSala"),null,rs.getString("sifraSala")));
            }
            cbSale.setItems(listSale);
            conn.close();

            lvGrupe.setItems(listGrupe);

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void tableNastavniciOnClick(MouseEvent e) {
        if(e.isPrimaryButtonDown()) {
            listGrupe.clear();
            try {
                Korisnik profesor = tableNastavnici.getSelectionModel().getSelectedItem();
                Connection conn = DBConnector.getConnection();
                ResultSet rs = conn.createStatement().executeQuery("SELECT DISTINCT idGrupa,sifraGrupa,vrsta FROM grupa WHERE idNastavnik = " + profesor.getIdKorisnik() + " ORDER BY idGrupa");
                while (rs.next()) {
                    listGrupe.add(new Grupa(rs.getInt("idGrupa"), null, null, rs.getString("sifraGrupa"), rs.getString("vrsta")));
                }
                lvGrupe.refresh();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public void recieveInfoFromLogin(Korisnik k) {
        korisnik = k;
        if(korisnik.isProdekan())
            listTip.add("cas");
        else {
            tableNastavnici.setVisible(false);
            lvGrupe.setVisible(false);
            etPretraziNastavnike.setVisible(false);
            btnPretraziNastavnike.setVisible(false);
            lblGrupa.setVisible(false);
            cbDan.setVisible(false);

            listNstavnikRezervacije.clear();
            try {
                Connection conn = DBConnector.getConnection();
                ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM rezervacija INNER JOIN sala ON rezervacija.idSala = sala.idSala INNER JOIN korisnik ON rezervacija.idKorisnik = korisnik.idKorisnik  LEFT JOIN grupa ON rezervacija.idGrupa = grupa.idGrupa WHERE rezervacija.idKorisnik = " + (int)korisnik.getIdKorisnik());

                while (rs.next()) {
                    Sala sala = new Sala(rs.getInt("idSala"), null, rs.getString("sifraSala"));
                    Korisnik nastavnik = new Korisnik(rs.getInt("idKorisnik"), rs.getString("korIme"), rs.getString("korSifra"),
                            rs.getString("imeKorisnik"), rs.getString("prezKorisnik"), rs.getBoolean("prodekan"), rs.getBoolean("profesor"),
                            rs.getBoolean("saradnik"));

                    Grupa grupa = new Grupa(rs.getInt("idGrupa"), null, null, rs.getString("sifraGrupa"), rs.getString("vrsta"));
                    listNstavnikRezervacije.add(new Rezervacija(rs.getInt("idRezervacija"), rs.getDate("datum"), rs.getTime("pocetak")
                            , rs.getTime("kraj"), rs.getString("tip"), sala, nastavnik, grupa,rs.getString("dan")));
                }
                rs.close();
                conn.close();
                tableRezervacije.setItems(listNstavnikRezervacije);
            }
            catch (Exception e) {
                e.printStackTrace();
            }


        }
    }

    public void btnNazadClicked(ActionEvent event) throws IOException {
        Parent root;
        if(korisnik.isProdekan())
            root = FXMLLoader.load(getClass().getResource("prodekan.fxml"));
        else
            root = FXMLLoader.load(getClass().getResource("nastavnik.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }


    public void pretragaNastavniciClicked() {
        String pretraga = etPretraziNastavnike.getText();
        if(etPretraziNastavnike.getText().trim().isEmpty() || pretraga == null) {
            tableNastavnici.setItems(listNastavnici);
            return;
        }
        listTrazeniNastavnici.clear();
        try {
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM korisnik WHERE imeKorisnik " +
                    "LIKE '%" + pretraga + "%' OR prezKorisnik LIKE '%" + pretraga + "%'");
            while (rs.next()) {
                listTrazeniNastavnici.add(new Korisnik(rs.getInt("idKorisnik"), rs.getString("korIme"),  rs.getString("korSifra"),
                        rs.getString("imeKorisnik"), rs.getString("prezKorisnik"),rs.getBoolean("prodekan"),rs.getBoolean("profesor"),
                        rs.getBoolean("saradnik")));
            }
            rs.close();
            conn.close();
            tableNastavnici.setItems(listTrazeniNastavnici);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void dodajRezervacijuProdekan(){
        if(!checkStandardInput()){
            return;
        }
        String tip = cbTip.getSelectionModel().getSelectedItem();
        if(tip.compareTo("cas")==0 && tableNastavnici.getSelectionModel().getSelectedItem() == null ){
            DBConnector.showAlert("Rezervacije", "Odaberite nastavnika");
            tableNastavnici.requestFocus();
            return;
        }
        if(tip.compareTo("cas")==0 && lvGrupe.getSelectionModel().getSelectedItem() == null ){
            DBConnector.showAlert("Rezervacije", "Odaberite grupu");
            lvGrupe.requestFocus();
            return;
        }
        Sala sala = cbSale.getSelectionModel().getSelectedItem();
        LocalDate datum = null;
        LocalTime pocetak = LocalTime.of(cbSatiPocetak.getSelectionModel().getSelectedItem(),0);
        LocalTime kraj = LocalTime.of(cbSatiKraj.getSelectionModel().getSelectedItem(),0);
        String dan = cbDan.getSelectionModel().getSelectedItem();

        Korisnik nastavnik = null;
        Grupa grupa = null;
        if(tip.compareTo("cas")==0) {
            nastavnik = tableNastavnici.getSelectionModel().getSelectedItem();
            grupa = lvGrupe.getSelectionModel().getSelectedItem();
        }
        else {
            datum = dpDatum.getValue();
        }

        for (Rezervacija e : listRezervacije) {
            if(tip.compareTo("cas")==0) {
                    if(dan.compareTo(e.getDan())==0 && isOverlapping(e.getPocetak(),e.getKraj(),Time.valueOf(pocetak),Time.valueOf(kraj)) && sala.getIdSala()==e.getSala().getIdSala()){
                        DBConnector.showAlert("Rezervacije", "Rezervacije se preklapaju!");
                        return;
                    }

            }
            else {
                String danrez = "";
                int day = getDayNumber(Date.valueOf(datum));
                if(day==2) danrez = "ponedjeljak";
                else if(day==3) danrez = "utorak";
                else if(day==4) danrez = "srijeda";
                else if(day==5) danrez = "cetvrtak";
                else if(day==6) danrez = "petak";
                else danrez = "subota";
                if(e.getTip().compareTo("cas")==0) {
                    if(danrez.compareTo(e.getDan())==0 && isOverlapping(e.getPocetak(),e.getKraj(),Time.valueOf(pocetak),Time.valueOf(kraj)) && sala.getIdSala()==e.getSala().getIdSala()){
                        DBConnector.showAlert("Rezervacije", "Rezervacije se preklapaju!");
                        return;
                    }
                }
                else{
                    if(Date.valueOf(datum).compareTo(e.getDatum())==0 && isOverlapping(e.getPocetak(),e.getKraj(),Time.valueOf(pocetak),Time.valueOf(kraj)) && sala.getIdSala()==e.getSala().getIdSala()){
                        DBConnector.showAlert("Rezervacije", "Rezervacije se preklapaju!");
                        return;
                    }
                }
            }

        }

        try{
            // JOS INSERT I DELETE NAPRAVI PAZI NA NASTAVNIKA
            Connection conn = DBConnector.getConnection();
            String query = "INSERT INTO rezervacija (datum, pocetak, kraj, tip, idSala ,idKorisnik, idGrupa, dan) VALUES (?,?,?,?,?,?,?,?) ";
            PreparedStatement ps = conn.prepareStatement(query);
            if(datum!=null)
            ps.setDate(1, Date.valueOf(datum));
            else
                ps.setNull(1,1);
            ps.setTime(2, Time.valueOf(pocetak));
            ps.setTime(3, Time.valueOf(kraj));
            ps.setString(4,tip);
            ps.setInt(5, sala.getIdSala());
            ps.setInt(6, korisnik.getIdKorisnik());
            ps.setInt(7,grupa.getIdGrupa());
            if(tip.compareTo("cas")!=0) {
                String danrez = "";
                int day = getDayNumber(Date.valueOf(datum));
                if (day == 2) danrez = "ponedjeljak";
                else if (day == 3) danrez = "utorak";
                else if (day == 4) danrez = "srijeda";
                else if (day == 5) danrez = "cetvrtak";
                else if (day == 6) danrez = "petak";
                else danrez = "subota";
                ps.setString(8,danrez);
            }
            else {
                ps.setString(8,dan);
            }

            if(ps.executeUpdate()>0) {
                DBConnector.showAlert("Rezervacije", "Unos uspjesan");
                ResultSet rs;
                String danFromSelect=dan;
                if(tip.compareTo("cas")!=0) {
                    int day = getDayNumber(Date.valueOf(datum));
                    if (day == 2) danFromSelect = "ponedjeljak";
                    else if (day == 3) danFromSelect = "utorak";
                    else if (day == 4) danFromSelect = "srijeda";
                    else if (day == 5) danFromSelect = "cetvrtak";
                    else if (day == 6) danFromSelect = "petak";
                    else danFromSelect = "subota";
                    ps.setString(8,danFromSelect);
                }

                listRezervacije.add(new Rezervacija(0, Date.valueOf(datum), Time.valueOf(pocetak), Time.valueOf(kraj), tip, sala, korisnik,grupa,danFromSelect));
                if(!korisnik.isProdekan()){
                    listNstavnikRezervacije.add(new Rezervacija(0, Date.valueOf(datum), Time.valueOf(pocetak), Time.valueOf(kraj), tip, sala, korisnik,grupa,danFromSelect));
                }
                conn.close();


            }
            else{
                DBConnector.showAlert("Predmeti", "Greska!");
                return;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }



    }

    public boolean isOverlapping(Time start1, Time end1, Time start2, Time end2) {
        return start1.before(end2) && start2.before(end1);
    }

    private boolean checkStandardInput() {
        if(cbSale.getSelectionModel().getSelectedItem() == null){
            DBConnector.showAlert("Rezervacije", "Odaberite salu");
            cbSale.requestFocus();
            return false;
        }
        if(cbTip.getSelectionModel().getSelectedItem() == null){
            DBConnector.showAlert("Rezervacije", "Odaberite tip");
            cbTip.requestFocus();
            return false;
        }
        String tip = cbTip.getSelectionModel().getSelectedItem();
        if(tip.compareTo("cas")!=0 && dpDatum.getValue() == null){
            DBConnector.showAlert("Rezervacije", "Unesite datum");
            dpDatum.requestFocus();
            return false;
        }
        if(cbSatiPocetak.getSelectionModel().getSelectedItem() == null){
            DBConnector.showAlert("Rezervacije", "Odaberite pocetak");
            cbSatiPocetak.requestFocus();
            return false;
        }
        if(cbSatiKraj.getSelectionModel().getSelectedItem() == null){
            DBConnector.showAlert("Rezervacije", "Odaberite kraj");
            cbSatiKraj.requestFocus();
            return false;
        }
        if(tip.compareTo("cas")==0 && cbDan.getSelectionModel().getSelectedItem()==null){
            DBConnector.showAlert("Rezervacije", "Odaberite dan");
            cbDan.requestFocus();
            return false;
        }
        return true;

    }


    public  int getDayNumber(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal.get(Calendar.DAY_OF_WEEK);
    }

}
