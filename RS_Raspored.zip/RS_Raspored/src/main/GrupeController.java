package main;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class GrupeController implements Initializable {
    @FXML
    private TableView<Grupa> tableGrupe;
    @FXML
    private TableColumn<Grupa, String> colSifGrupa;
    @FXML
    private TableColumn<Grupa, String> colPredmet;
    @FXML
    private TableColumn<Grupa, String> colNastavnik;
    @FXML
    private TableColumn<Grupa, String> colVrsta;

    @FXML
    private TableView<Predmet> tablePredmeti;
    @FXML
    private TableColumn<Predmet, String> colNazivPredmet;

    @FXML
    private ListView<Korisnik> lvNastavnik;
    @FXML
    private TextField etPretraziPredmete;
    @FXML
    private TextField etPretraziGrupe;
    @FXML
    private TextField etSifGrupa;


    @FXML
    private ComboBox<String> cbVrsta;

    ObservableList<Grupa> listGrupe = FXCollections.observableArrayList();
    ObservableList<Grupa> listTrazeneGrupe = FXCollections.observableArrayList();
    ObservableList<Predmet> listPredmeti = FXCollections.observableArrayList();
    ObservableList<Korisnik> listNastavnik = FXCollections.observableArrayList();
    ObservableList<String> listVrsta = FXCollections.observableArrayList();
    ObservableList<Predmet> listTrazeniPredmeti = FXCollections.observableArrayList();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        listVrsta.add(new String("Predavanja"));
        listVrsta.add(new String("Auditorne vježbe"));
        listVrsta.add(new String("Laboratorijske vježbe"));
        cbVrsta.setItems(listVrsta);
        try {
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM grupa INNER JOIN predmet ON grupa.idPredmet = predmet.idPredmet INNER JOIN korisnik ON grupa.idNastavnik = korisnik.idKorisnik ORDER BY idGrupa");
            while (rs.next()) {
                Korisnik nastavnik = new Korisnik(rs.getInt("idKorisnik"), rs.getString("korIme"),  rs.getString("korSifra"),
                        rs.getString("imeKorisnik"), rs.getString("prezKorisnik"),rs.getBoolean("prodekan"),rs.getBoolean("profesor"),
                        rs.getBoolean("saradnik"));
                Predmet predmet = (new Predmet(rs.getInt("idPredmet"), rs.getString("nazivPredmet"), rs.getString("sifraPredmet"),null,null));
                listGrupe.add(new Grupa(rs.getInt("idGrupa"),predmet,nastavnik,rs.getString("sifraGrupa"), rs.getString("vrsta")));
            }
            rs.close();

            colSifGrupa.setCellValueFactory(new PropertyValueFactory<>("sifraGrupa"));
            colPredmet.setCellValueFactory(new PropertyValueFactory<>("predmet"));
            colNastavnik.setCellValueFactory(new PropertyValueFactory<>("nastavnik"));
            colVrsta.setCellValueFactory(new PropertyValueFactory<>("vrsta"));
            tableGrupe.setItems(listGrupe);

            //===================================Predmeti==============================================

            rs = conn.createStatement().executeQuery("SELECT DISTINCT * FROM predmet ORDER BY idPredmet");
            while (rs.next()) {
                listPredmeti.add(new Predmet(rs.getInt("idPredmet"), rs.getString("nazivPredmet"), rs.getString("sifraPredmet"),null,null));
            }
            rs.close();
            colNazivPredmet.setCellValueFactory(new PropertyValueFactory<>("nazivPredmet"));
            tablePredmeti.setItems(listPredmeti);

            conn.close();
            lvNastavnik.setItems(listNastavnik);

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void pretraziPredmeteClicked(){
        String pretraga = etPretraziPredmete.getText();
        if(etPretraziPredmete.getText().trim().isEmpty() || pretraga == null) {
            tablePredmeti.setItems(listPredmeti);
            return;
        }
        listTrazeniPredmeti.clear();
        try {
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM predmet WHERE nazivPredmet " +
                    "LIKE '%" + pretraga + "%'");
            while (rs.next()) {
                listTrazeniPredmeti.add(new Predmet(rs.getInt("idPredmet"), rs.getString("nazivPredmet"), rs.getString("sifraPredmet"),null,null));

            }
            rs.close();
            conn.close();
            tablePredmeti.setItems(listTrazeniPredmeti);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void pretraziGrupeClicked(){
        String pretraga = etPretraziGrupe.getText();
        if(etPretraziGrupe.getText().trim().isEmpty() || pretraga == null) {
            try{
                Connection conn = DBConnector.getConnection();
                fetchGrupe(conn);
                conn.close();

            }
            catch (Exception e) {
                e.printStackTrace();
            }
            tableGrupe.setItems(listGrupe);
            listTrazeneGrupe.clear();
            return;
        }
        listTrazeneGrupe.clear();
        try{
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM grupa INNER JOIN predmet ON grupa.idPredmet = predmet.idPredmet INNER JOIN korisnik" +
                    " ON grupa.idNastavnik = korisnik.idKorisnik WHERE sifraGrupa LIKE '%" + pretraga + "%' OR nazivPredmet LIKE '%" + pretraga + "%' OR" +
                    " imeKorisnik LIKE '%" + pretraga + "%' OR prezKorisnik LIKE '%" + pretraga + "%' OR vrsta LIKE '%" + pretraga + "%'");
            while(rs.next()){
                Korisnik nastavnik = new Korisnik(rs.getInt("idKorisnik"), rs.getString("korIme"),  rs.getString("korSifra"),
                        rs.getString("imeKorisnik"), rs.getString("prezKorisnik"),rs.getBoolean("prodekan"),rs.getBoolean("profesor"),
                        rs.getBoolean("saradnik"));
                Predmet predmet = (new Predmet(rs.getInt("idPredmet"), rs.getString("nazivPredmet"), rs.getString("sifraPredmet"),null,null));
                listTrazeneGrupe.add(new Grupa(rs.getInt("idGrupa"),predmet,nastavnik,rs.getString("sifraGrupa"), rs.getString("vrsta")));
            }
            rs.close();
            conn.close();
            tableGrupe.setItems(listTrazeneGrupe);

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onPredmetClicked(MouseEvent e){
        if(e.isPrimaryButtonDown()){
            Predmet predmet = tablePredmeti.getSelectionModel().getSelectedItem();
            listNastavnik.clear();
            try{
                Connection conn = DBConnector.getConnection();
                ResultSet rs = conn.createStatement().executeQuery("SELECT idKorisnik,imeKorisnik,prezKorisnik FROM nastavnici " +
                        " INNER JOIN korisnik ON nastavnici.idNastavnik = korisnik.idKorisnik WHERE idPredmet = " + predmet.getIdPredmet());
                while(rs.next()) {
                    listNastavnik.add(new Korisnik(rs.getInt("idKorisnik"),null,null,rs.getString("imeKorisnik"),rs.getString("prezKorisnik"),false,false,false));
                }
                rs.close();
                conn.close();
            }
            catch (Exception err) {
                err.printStackTrace();
            }

        }
    }


    public void btnNazadClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("prodekan.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    private void fetchGrupe(Connection conn) {
        listGrupe.clear();
        try{
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM grupa INNER JOIN predmet ON grupa.idPredmet = predmet.idPredmet INNER JOIN korisnik ON grupa.idNastavnik = korisnik.idKorisnik ORDER BY idGrupa");
            while (rs.next()) {
                Korisnik nastavnik = new Korisnik(rs.getInt("idKorisnik"), rs.getString("korIme"),  rs.getString("korSifra"),
                        rs.getString("imeKorisnik"), rs.getString("prezKorisnik"),rs.getBoolean("prodekan"),rs.getBoolean("profesor"),
                        rs.getBoolean("saradnik"));
                Predmet predmet = (new Predmet(rs.getInt("idPredmet"), rs.getString("nazivPredmet"), rs.getString("sifraPredmet"),null,null));
                listGrupe.add(new Grupa(rs.getInt("idGrupa"),predmet,nastavnik,rs.getString("sifraGrupa"), rs.getString("vrsta")));
            }
            rs.close();
        }
        catch (Exception err) {
            err.printStackTrace();
        }
    }


    public void dodajGrupuClicked(){
        if(etSifGrupa.getText().trim().isEmpty()) {
            DBConnector.showAlert("Grupe", "Unesite sifru grupe!");
            etSifGrupa.requestFocus();
            return;
        }
        if(cbVrsta.getSelectionModel().getSelectedItem()==null){
            DBConnector.showAlert("Grupe", "Odaberite vrstu!");
            cbVrsta.requestFocus();
            return;
        }
        if(tablePredmeti.getSelectionModel().getSelectedItem()==null){
            DBConnector.showAlert("Grupe", "Odaberite predmet!");
            tablePredmeti.requestFocus();
            return;
        }
        if(lvNastavnik.getSelectionModel().getSelectedItem()==null){
            DBConnector.showAlert("Grupe", "Odaberite nastavnika!");
            lvNastavnik.requestFocus();
            return;
        }
        String sifGrupa = etSifGrupa.getText();
        String vrsta = cbVrsta.getSelectionModel().getSelectedItem();
        Predmet predmet = tablePredmeti.getSelectionModel().getSelectedItem();
        Korisnik nastavnik = lvNastavnik.getSelectionModel().getSelectedItem();
        for(Grupa e : listGrupe){
            if(sifGrupa.toLowerCase().compareTo(e.getSifraGrupa().toLowerCase())==0){
                DBConnector.showAlert("Grupe", "Grupa vec postoji!");
                return;
            }
        }
        if(vrsta.compareTo("Predavanja")==0) vrsta="P";
        else if(vrsta.compareTo("Auditorne vježbe")==0) vrsta="A";
        else vrsta="L";

        try{
            Connection conn = DBConnector.getConnection();
            String query = "INSERT INTO grupa (idPredmet, idNastavnik, sifraGrupa, vrsta) VALUES (?,?,?,?) ";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, predmet.getIdPredmet());
            ps.setInt(2, nastavnik.getIdKorisnik());
            ps.setString(3, sifGrupa);
            ps.setString(4, vrsta);
            if(ps.executeUpdate()>0) {
                DBConnector.showAlert("Grupe", "Unos uspjesan!");
                listGrupe.add(new Grupa(0,predmet,nastavnik,sifGrupa,vrsta));
                etSifGrupa.clear();

            }
            else {
                DBConnector.showAlert("Grupe", "Greska!");
                return;
            }
        }
        catch (Exception err) {
            err.printStackTrace();
        }

    }


    public void obrisiGrupeClicked(){
        Grupa odabranaGrupa = tableGrupe.getSelectionModel().getSelectedItem();
        if(odabranaGrupa == null) {
            DBConnector.showAlert("Grupe", "Molimo odaberite grupu!");
            tableGrupe.requestFocus();
            return;
        }
        int selectedIndex = tableGrupe.getSelectionModel().getSelectedIndex();
        try{
            Connection conn = DBConnector.getConnection();
            String query = "DELETE FROM grupa WHERE sifraGrupa = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1,odabranaGrupa.getSifraGrupa());
            if(ps.executeUpdate()>0) {
                DBConnector.showAlert("Grupe", "Brisanje uspjesno!");
                if(listTrazeneGrupe.isEmpty()){
                    listGrupe.remove(selectedIndex);
                }
                else {
                    listTrazeneGrupe.remove(selectedIndex);
                    fetchGrupe(conn);
                }
            }
            else {
                DBConnector.showAlert("Grupe", "Greska!");
            }
            conn.close();

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void urediGrupeClicked() throws IOException{
        Grupa selectedGrupa = tableGrupe.getSelectionModel().getSelectedItem();
        int selectedIndex = tableGrupe.getSelectionModel().getFocusedIndex();
        if(selectedGrupa == null) {
            DBConnector.showAlert("Grupe", "Molimo izaberite grupu!");
            return;
        }
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("grupeUredi.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        UrediGrupeController urediController = fxmlLoader.getController();
        urediController.recieveInfoFromGrupe(selectedGrupa,selectedIndex,tableGrupe,listGrupe,listPredmeti,listVrsta,listTrazeneGrupe,listNastavnik);
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Uredi grupu");
        stage.setResizable(false);
        stage.setScene(new Scene(root1));
        stage.show();

    }

}
