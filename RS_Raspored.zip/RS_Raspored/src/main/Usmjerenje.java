package main;

public class Usmjerenje {

    private Integer idUsmjerenje;
    private String sifraUsmjerenje;
    private String nazivUsmjerenje;

    public Usmjerenje(){};

    public Usmjerenje(int idUsmjerenje, String sifraUsmjerenje, String nazivUsmjerenje){
        this.idUsmjerenje = idUsmjerenje;
        this.sifraUsmjerenje = sifraUsmjerenje;
        this.nazivUsmjerenje = nazivUsmjerenje;
    }

    public int getIdUsmjerenje() {
        return idUsmjerenje;
    }

    public void setIdUsmjerenje(int idUsmjerenje) {
        this.idUsmjerenje = idUsmjerenje;
    }

    public String getSifraUsmjerenje() {
        return sifraUsmjerenje;
    }

    public void setSifraUsmjerenje(String sifraUsmjerenje) {
        this.sifraUsmjerenje = sifraUsmjerenje;
    }

    public String getNazivUsmjerenje() {
        return nazivUsmjerenje;
    }

    public void setNazivUsmjerenje(String nazivUsmjerenje) {
        this.nazivUsmjerenje = nazivUsmjerenje;
    }

    @Override
    public String toString() {
        return nazivUsmjerenje;
    }
}
