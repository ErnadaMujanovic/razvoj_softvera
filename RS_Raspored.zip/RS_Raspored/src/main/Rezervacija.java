package main;

import java.sql.Date;
import java.sql.Time;

public class Rezervacija {

    private Integer idRezervacija;
    private Date datum;
    private Time pocetak, kraj;
    private String tip;
    private Sala sala;
    private Korisnik korisnik;
    private Grupa grupa;
    private String dan;

    public Rezervacija(){}

    public Rezervacija(Integer idRezervacija, Date datum, Time pocetak, Time kraj, String tip, Sala sala, Korisnik korisnik, Grupa grupa, String dan){
        this.idRezervacija = idRezervacija;
        this.datum = datum;
        this.pocetak = pocetak;
        this.kraj = kraj;
        this.tip = tip;
        this.sala = sala;
        this.korisnik = korisnik;
        this.grupa = grupa;
        this.dan = dan;
    }

    public int getIdRezervacija() {
        return idRezervacija;
    }

    public void setIdRezervacija(int idRezervacija) {
        this.idRezervacija = idRezervacija;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public Time getPocetak() {
        return pocetak;
    }

    public void setPocetak(Time pocetak) {
        this.pocetak = pocetak;
    }

    public Time getKraj() {
        return kraj;
    }

    public void setKraj(Time kraj) {
        this.kraj = kraj;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getDan() {
        return dan;
    }

    public void setDan(String dan) {
        this.dan = dan;
    }

    public Sala getSala() {
        return sala;
    }

    public void setSala(Sala sala) {
        this.sala = sala;
    }

    public Korisnik getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(Korisnik korisnik) {
        this.korisnik = korisnik;
    }

    public Grupa getGrupa() {
        return grupa;
    }

    public void setGrupa(Grupa grupa) {
        this.grupa = grupa;
    }
}
