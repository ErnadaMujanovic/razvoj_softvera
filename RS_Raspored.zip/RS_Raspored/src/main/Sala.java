package main;

public class Sala {

    private Integer idSala;
    private Zgrada zgrada;
    private String sifraSala;

    public Sala(){}

    public Sala(Integer idSala, Zgrada zgrada, String sifraSala){
        this.idSala = idSala;
        this.zgrada = zgrada;
        this.sifraSala =sifraSala;
    }

    public int getIdSala() {
        return idSala;
    }

    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }

    public Zgrada getZgrada() {
        return zgrada;
    }

    public void setZgrada(Zgrada zgrada) {
        this.zgrada = zgrada;
    }

    public String getSifraSala() {
        return sifraSala;
    }

    public void setSifraSala(String sifraSala) {
        this.sifraSala = sifraSala;
    }

    @Override
    public String toString() {
        return sifraSala;
    }
}
