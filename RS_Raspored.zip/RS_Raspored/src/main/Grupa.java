package main;

public class Grupa {

    private Integer idGrupa;
    private Predmet predmet;
    private Korisnik nastavnik;
    private String sifraGrupa, vrsta;

    public Grupa(){}

    public Grupa(Integer idGrupa, Predmet predmet, Korisnik nastavnik, String sifraGrupa, String vrsta){
        this.idGrupa = idGrupa;
        this.predmet = predmet;
        this.nastavnik = nastavnik;
        this.sifraGrupa = sifraGrupa;
        this.vrsta = vrsta;
    }

    public int getIdGrupa() {
        return idGrupa;
    }

    public void setIdGrupa(int idGrupa) {
        this.idGrupa = idGrupa;
    }

    public Predmet getPredmet() {
        return predmet;
    }

    public void setPredmet(Predmet predmet) {
        this.predmet = predmet;
    }

    public Korisnik getNastavnik() {
        return nastavnik;
    }

    public void setNastavnik(Korisnik nastavnik) {
        this.nastavnik = nastavnik;
    }

    public String getSifraGrupa() {
        return sifraGrupa;
    }

    public void setSifraGrupa(String sifraGrupa) {
        this.sifraGrupa = sifraGrupa;
    }

    public String getVrsta() {
        return vrsta;
    }

    public void setVrsta(String vrsta) {
        this.vrsta = vrsta;
    }

    @Override
    public String toString() {
        return sifraGrupa;
    }
}
