package main;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class urediSaleController {

    @FXML
    private TextField etSifSale;
    @FXML
    private ComboBox<Zgrada> cbZgrada;
    @FXML
    private TableView<Sala> tableSale;

    private Sala selectedSala;
    private int selectedIndex;
    private ObservableList<Zgrada> listZgrade;
    private ObservableList<Sala> listSale;

    public void recieveInfoFromSale(Sala sala, int index, ObservableList<Zgrada> zgrade, ObservableList<Sala> sale, TableView<Sala> table){
        selectedSala=sala;
        selectedIndex=index;
        listZgrade = zgrade;
        listSale = sale;
        tableSale = table;
        etSifSale.setText(selectedSala.getSifraSala());
        cbZgrada.setItems(zgrade);
        cbZgrada.getSelectionModel().select(selectedSala.getZgrada());
    }


    public void sacuvajClicked(){
        String sifSala = etSifSale.getText();
        Zgrada zgrada = cbZgrada.getSelectionModel().getSelectedItem();

        for(Sala e : listSale) {
            if ((sifSala.compareTo(e.getSifraSala())) == 0 && zgrada.getIdZgrada() == e.getZgrada().getIdZgrada()) {
                DBConnector.showAlert("Sale", "Sala vec postoji!");
                return;
            }
        }
        try {
            Connection conn = DBConnector.getConnection();
            String query = "UPDATE sala SET sifraSala = ?, idZgrada = ? WHERE idSala = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, sifSala);
            ps.setInt(2,zgrada.getIdZgrada());
            ps.setInt(3,selectedSala.getIdSala());
            if(ps.executeUpdate()>0) {
                DBConnector.showAlert("Sale", "Sacuvano!");
                conn.close();
                selectedSala.setSifraSala(sifSala);
                selectedSala.setZgrada(zgrada);
                listSale.set(selectedIndex, selectedSala);
                Stage stage = (Stage) etSifSale.getScene().getWindow();
                stage.close();
                tableSale.refresh();
            }
            else
                DBConnector.showAlert("Sale", "Greska!");
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

}
