package main;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class predmetiController implements Initializable {
    @FXML
    private TableView<Predmet> tablePredmeti;
    @FXML
    private TableColumn<Predmet, String> colsifPredmet;
    @FXML
    private TableColumn<Predmet, String> colNazivPredmet;
    @FXML
    private TableColumn<Korisnik, String> colProfesor;
    @FXML
    private TableColumn<Semestar, String> colSemestar;

    @FXML
    private TableView<Korisnik> tableProfesori;
    @FXML
    private TableColumn<Korisnik, String> colIme;
    @FXML
    private TableColumn<Korisnik, String> colPrezime;


    @FXML
    private TextField etPretraziProfesore;
    @FXML
    private TextField etsifPredmet;
    @FXML
    private TextField etNazivPredmet;
    @FXML
    private TextField etPretraziPredmete;

    @FXML
    private ComboBox<Semestar> cbSemestar;
    @FXML
    private ListView<Usmjerenje> lvUsmjerenja;
    @FXML
    private ListView<Usmjerenje> lvOdabranaUsmjerenja;
    @FXML
    private ListView<Korisnik> lvOdabraniNastavnici;
    @FXML
    private ListView<ComboBox<Integer>> lvGodine;

    ObservableList<Predmet> listPredmeti = FXCollections.observableArrayList();
    ObservableList<Korisnik> listProfesori = FXCollections.observableArrayList();
    ObservableList<Semestar> listSemestar = FXCollections.observableArrayList();
    ObservableList<Korisnik> listOdabraniNastavnici = FXCollections.observableArrayList();
    ObservableList<Usmjerenje> listUsmjerenja = FXCollections.observableArrayList();
    ObservableList<Usmjerenje> listOdabranaUsmjerenja = FXCollections.observableArrayList();
    ObservableList<ComboBox<Integer>> listGodine = FXCollections.observableArrayList();
    ObservableList<Integer> listGod = FXCollections.observableArrayList();
    ObservableList<Korisnik> listTrazeniProfesori = FXCollections.observableArrayList();
    ObservableList<Predmet> listTrazeniPredmeti = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        for(Integer i=1; i<5; ++i)
            listGod.add(i);
        try{
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM predmet INNER JOIN korisnik ON predmet.idNosioc = korisnik.idKorisnik INNER JOIN semestar ON predmet.idSemestar = semestar.idSemestar ORDER BY idPredmet");
            while (rs.next()) {
                Korisnik profesor = new Korisnik(rs.getInt("idNosioc"), rs.getString("korIme"),  rs.getString("korSifra"),
                        rs.getString("imeKorisnik"), rs.getString("prezKorisnik"),rs.getBoolean("prodekan"),rs.getBoolean("profesor"),
                        rs.getBoolean("saradnik"));
                Semestar semestar = new Semestar(rs.getInt("idSemestar"),rs.getString("pocetak"),rs.getString("kraj"),rs.getString("nazivSemestar"));
                listPredmeti.add(new Predmet(rs.getInt("idPredmet"), rs.getString("nazivPredmet"), rs.getString("sifraPredmet"),profesor,semestar));
            }
            rs.close();
            colsifPredmet.setCellValueFactory(new PropertyValueFactory<>("sifraPredmet"));
            colNazivPredmet.setCellValueFactory(new PropertyValueFactory<>("nazivPredmet"));
            colProfesor.setCellValueFactory(new PropertyValueFactory<>("nosioc"));
            colSemestar.setCellValueFactory(new PropertyValueFactory<>("semestar"));
            tablePredmeti.setItems(listPredmeti);

 //===================================PROFESORI==============================================

            rs = conn.createStatement().executeQuery("SELECT * FROM korisnik ORDER BY imeKorisnik");
            while (rs.next()) {
                listProfesori.add(new Korisnik(rs.getInt("idKorisnik"), rs.getString("korIme"),  rs.getString("korSifra"),
                        rs.getString("imeKorisnik"), rs.getString("prezKorisnik"),rs.getBoolean("prodekan"),rs.getBoolean("profesor"),
                        rs.getBoolean("saradnik")));
            }
            rs.close();
            colIme.setCellValueFactory(new PropertyValueFactory<>("imeKorisnik"));
            colPrezime.setCellValueFactory(new PropertyValueFactory<>("prezKorisnik"));
            tableProfesori.setItems(listProfesori);

//===================================SEMESTRI==============================================
            rs = conn.createStatement().executeQuery("SELECT * FROM semestar ORDER BY idSemestar");
            while (rs.next()) {
                listSemestar.add(new Semestar(rs.getInt("idSemestar"), rs.getString("pocetak"), rs.getString("kraj"), rs.getString("nazivSemestar")));
            }
            rs.close();
            cbSemestar.setItems(listSemestar);

//===================================USMJERENJA ==============================================
            rs = conn.createStatement().executeQuery("SELECT * FROM usmjerenje ORDER BY idUsmjerenje");
            while (rs.next()) {
                listUsmjerenja.add(new Usmjerenje(rs.getInt("idUsmjerenje"), rs.getString("sifraUsmjerenje"), rs.getString("nazivUsmjerenje")));
            }
            lvUsmjerenja.setItems(listUsmjerenja);

            lvOdabraniNastavnici.setItems(listOdabraniNastavnici);

            lvOdabranaUsmjerenja.setItems(listOdabranaUsmjerenja);
            lvGodine.setItems(listGodine);
            conn.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }


    }




    public void rightClickProfesor(MouseEvent e) {

        if(e.isSecondaryButtonDown()) {
            Korisnik selectedProfesor = tableProfesori.getSelectionModel().getSelectedItem();
            for(Korisnik kor : listOdabraniNastavnici) {
                if(kor.getIdKorisnik() == selectedProfesor.getIdKorisnik()) {
                    DBConnector.showAlert("Predmeti", "Vec ste odabrali tog nastavnika!");
                    return;
                }
            }
            listOdabraniNastavnici.add(selectedProfesor);
            lvOdabraniNastavnici.refresh();
        }
    }

    public void rightClickLVProfesor(MouseEvent e) {
        if(e.isSecondaryButtonDown()) {
            int selectedIndex = lvOdabraniNastavnici.getSelectionModel().getSelectedIndex();
            listOdabraniNastavnici.remove(selectedIndex);
            lvOdabraniNastavnici.refresh();
            tableProfesori.requestFocus();
        }
    }

    public void usmjerenjeMoveRight(){
        Usmjerenje selectedUsmjerenje = lvUsmjerenja.getSelectionModel().getSelectedItem();
        if(selectedUsmjerenje == null) {
            DBConnector.showAlert("Predmeti", "Odaberite usmjerenje!");
            lvUsmjerenja.requestFocus();
            return;
        }
        int selectedIndex = lvUsmjerenja.getSelectionModel().getSelectedIndex();
        listOdabranaUsmjerenja.add(selectedUsmjerenje);
        listUsmjerenja.remove(selectedIndex);

        ComboBox<Integer> cbGod = new ComboBox<Integer>(listGod);
        listGodine.add(cbGod);

        lvOdabranaUsmjerenja.refresh();
        lvUsmjerenja.refresh();
    }

    public void usmjerenjeMoveLeft(){
        Usmjerenje selectedUsmjerenje = lvOdabranaUsmjerenja.getSelectionModel().getSelectedItem();
        int selectedId = lvOdabranaUsmjerenja.getSelectionModel().getSelectedIndex();
        if(selectedUsmjerenje == null) {
            DBConnector.showAlert("Predmeti", "Odaberite usmjerenje!");
            lvOdabranaUsmjerenja.requestFocus();
            return;
        }
        int selectedIndex = lvOdabranaUsmjerenja.getSelectionModel().getSelectedIndex();
        listUsmjerenja.add(selectedUsmjerenje);
        listOdabranaUsmjerenja.remove(selectedIndex);
        listGodine.remove(selectedId);

        lvOdabranaUsmjerenja.refresh();
        lvUsmjerenja.refresh();
    }

    public void obrisiPredmetClicked(){
        Predmet odabraniPredmet = tablePredmeti.getSelectionModel().getSelectedItem();
        if(odabraniPredmet == null) {
            DBConnector.showAlert("Predmeti", "Molimo odaberite predmet!");
            tablePredmeti.requestFocus();
            return;
        }
        int selectedIndex = tablePredmeti.getSelectionModel().getSelectedIndex();
        try{
            Connection conn = DBConnector.getConnection();
            String query = "DELETE FROM predmet WHERE idPredmet = ? ";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1,odabraniPredmet.getIdPredmet());
            if(ps.executeUpdate()>0) {
                DBConnector.showAlert("Predmeti", "Brisanje uspjesno!");
                if(listTrazeniPredmeti.isEmpty()){
                    listPredmeti.remove(selectedIndex);
                }
                else {
                    listTrazeniPredmeti.remove(selectedIndex);
                    fetchPredmeti(conn);
                }
            }
            else {
                DBConnector.showAlert("Predmeti", "Greska!");
            }
            conn.close();

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void dodajPredmetClicked() {
        if(!checkInput()){
            return;
        }
        String naziv = etNazivPredmet.getText();
        String sifra = etsifPredmet.getText();
        Korisnik Nosioc = tableProfesori.getSelectionModel().getSelectedItem();
        Semestar Semestar = cbSemestar.getSelectionModel().getSelectedItem();

        for(Predmet e : listPredmeti){
            if(naziv.toLowerCase().compareTo(e.getNazivPredmet().toLowerCase())==0 || sifra.toLowerCase().compareTo(e.getSifraPredmet().toLowerCase())==0){
                DBConnector.showAlert("Predmeti", "Predmet vec postoji!");
                return;
            }
        }
        try{
            //================================== tabela predmet ===================================

            Connection conn = DBConnector.getConnection();
            String query = "INSERT INTO predmet (nazivPredmet, sifraPredmet, idNosioc, idSemestar) VALUES (?,?,?,?) ";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, naziv);
            ps.setString(2, sifra);
            ps.setInt(3, Nosioc.getIdKorisnik());
            ps.setInt(4, Semestar.getIdSemestar());
            if(ps.executeUpdate()>0) {
                DBConnector.showAlert("Predmeti", "Unos uspjesan");
                ResultSet rs = conn.createStatement().executeQuery("SELECT idPredmet FROM predmet WHERE nazivPredmet = '" + naziv + "'" +
                        "AND sifraPredmet = '" + sifra + "' AND idNosioc = " + Nosioc.getIdKorisnik() + " AND idSemestar = " + Semestar.getIdSemestar());
                int id=0;
                while(rs.next()) {
                    id = rs.getInt("idPredmet");
                    System.out.println(id);
                }

                listPredmeti.add(new Predmet(id,naziv,sifra,Nosioc,Semestar));
                tablePredmeti.refresh();
                etsifPredmet.clear();
                etNazivPredmet.clear();
                listOdabraniNastavnici.clear();
                for(Usmjerenje e : listOdabranaUsmjerenja){
                    listUsmjerenja.add(e);
                }
                listOdabranaUsmjerenja.clear();
                listGodine.clear();
            }
            else{
                DBConnector.showAlert("Predmeti", "Greska!");
                return;
            }

            //================================== tabela predmetiiii ===================================
            int id = listPredmeti.get(listPredmeti.size()-1).getIdPredmet();
            int i=0;
            for(Usmjerenje e : listOdabranaUsmjerenja) {
                int god = listGodine.get(i).getSelectionModel().getSelectedItem();
                query = "INSERT INTO predmeti VALUES (" + id + ", " + e.getIdUsmjerenje() + ", "  + god + ")";
                ps = conn.prepareStatement(query);
                ps.executeUpdate();
            }

            //================================== tabela nastavnici ===================================

            i=0;
            for(Korisnik e : listOdabraniNastavnici) {
                query = "INSERT INTO nastavnici VALUES (" + id + ", " + e.getIdKorisnik() +")";
                ps = conn.prepareStatement(query);
                ps.executeUpdate();
            }
            conn.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }



    public void btnNazadClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("prodekan.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    public void pretragaClicked() {
        String pretraga = etPretraziProfesore.getText();
        if(etPretraziProfesore.getText().trim().isEmpty() || pretraga == null) {
            tableProfesori.setItems(listProfesori);
            return;
        }
        listTrazeniProfesori.clear();
        try {
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM korisnik WHERE imeKorisnik " +
                    "LIKE '%" + pretraga + "%' OR prezKorisnik LIKE '%" + pretraga + "%'");
            while (rs.next()) {
                listTrazeniProfesori.add(new Korisnik(rs.getInt("idKorisnik"), rs.getString("korIme"),  rs.getString("korSifra"),
                        rs.getString("imeKorisnik"), rs.getString("prezKorisnik"),rs.getBoolean("prodekan"),rs.getBoolean("profesor"),
                        rs.getBoolean("saradnik")));
            }
            rs.close();
            conn.close();
            tableProfesori.setItems(listTrazeniProfesori);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void pretragaPredmetClicked(){
        String pretraga = etPretraziPredmete.getText();
        if(etPretraziPredmete.getText().trim().isEmpty() || pretraga == null) {
            try{
                Connection conn = DBConnector.getConnection();
                fetchPredmeti(conn);
                conn.close();

            }
            catch (Exception e) {
                e.printStackTrace();
            }
            tablePredmeti.setItems(listPredmeti);
            listTrazeniPredmeti.clear();
            return;
        }
        listTrazeniPredmeti.clear();
        try {
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM predmet INNER JOIN korisnik ON predmet.idNosioc=korisnik.idKorisnik" +
                    " INNER JOIN semestar ON predmet.idSemestar=semestar.idSemestar WHERE sifraPredmet LIKE '%" + pretraga + "%' " +
                    "OR nazivPredmet LIKE '%" + pretraga + "%' OR imeKorisnik " +
                    "LIKE '%" + pretraga + "%' OR prezKorisnik LIKE '%" + pretraga + "%' OR nazivSemestar LIKE '%" + pretraga + "%'");
            while(rs.next()) {
                Korisnik profesor = new Korisnik(rs.getInt("idNosioc"), rs.getString("korIme"),  rs.getString("korSifra"),
                        rs.getString("imeKorisnik"), rs.getString("prezKorisnik"),rs.getBoolean("prodekan"),rs.getBoolean("profesor"),
                        rs.getBoolean("saradnik"));
                Semestar semestar = new Semestar(rs.getInt("idSemestar"),rs.getString("pocetak"),rs.getString("kraj"),rs.getString("nazivSemestar"));
                listTrazeniPredmeti.add(new Predmet(rs.getInt("idPredmet"), rs.getString("nazivPredmet"), rs.getString("sifraPredmet"),profesor,semestar));
            }
            rs.close();
            conn.close();
            tablePredmeti.setItems(listTrazeniPredmeti);

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void fetchPredmeti(Connection conn){
        listPredmeti.clear();
        try{
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM predmet INNER JOIN korisnik ON predmet.idNosioc = korisnik.idKorisnik INNER JOIN semestar ON predmet.idSemestar = semestar.idSemestar ORDER BY idPredmet");
            while (rs.next()) {
                Korisnik profesor = new Korisnik(rs.getInt("idNosioc"), rs.getString("korIme"), rs.getString("korSifra"),
                        rs.getString("imeKorisnik"), rs.getString("prezKorisnik"), rs.getBoolean("prodekan"), rs.getBoolean("profesor"),
                        rs.getBoolean("saradnik"));
                Semestar semestar = new Semestar(rs.getInt("idSemestar"), rs.getString("pocetak"), rs.getString("kraj"), rs.getString("nazivSemestar"));
                listPredmeti.add(new Predmet(rs.getInt("idPredmet"), rs.getString("nazivPredmet"), rs.getString("sifraPredmet"), profesor, semestar));
            }
        }
        catch (Exception e) {
                e.printStackTrace();
            }
    }


    private boolean checkInput(){
        if(etsifPredmet.getText().trim().isEmpty()) {
            DBConnector.showAlert("Predmeti", "Unesite sifru predmeta!");
            etsifPredmet.requestFocus();
            return false;
        }

        if(etNazivPredmet.getText().trim().isEmpty()) {
            DBConnector.showAlert("Predmeti", "Unesite naziv predmeta!");
            etNazivPredmet.requestFocus();
            return false;
        }

        Semestar semestar = cbSemestar.getSelectionModel().getSelectedItem();
        if(semestar == null){
            DBConnector.showAlert("Predmeti", "Odaberite semestar!");
            cbSemestar.requestFocus();
            return false;
        }

        Korisnik profesor = tableProfesori.getSelectionModel().getSelectedItem();
        if(profesor == null){
            DBConnector.showAlert("Predmeti", "Odaberite profesora (nosioca predmeta)!");
            tableProfesori.requestFocus();
            return false;
        }
        if(listOdabraniNastavnici.isEmpty()){
            DBConnector.showAlert("Predmeti", "Odaberite nastavnike na predmetu (Desni klik)!");
            tableProfesori.requestFocus();
            return false;
        }
        if(listOdabranaUsmjerenja.isEmpty()){
            DBConnector.showAlert("Predmeti", "Odaberite usmjerenja!");
            lvUsmjerenja.requestFocus();
            return false;
        }
        for(ComboBox<Integer> e : listGodine) {
            if(e.getSelectionModel().getSelectedItem() == null){
                DBConnector.showAlert("Predmeti", "Odaberite godinu za svako usmjerenje!");
                e.requestFocus();
                return false;
            }
        }
        return true;
    }




}
