package main;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;

public class urediZgradeController {
    @FXML
    private TextField etnoviNaziv;

    private Zgrada zgrada;

    private int selectedIndex;

    private ObservableList<Zgrada> list;

    @FXML
    private TableView<Zgrada> zgradeTable;





    public void recieveInfoFromZgrade(Zgrada selectedZgrada, ObservableList<Zgrada> oblist, TableView<Zgrada> table, int index){
        zgrada = selectedZgrada;
        list = oblist;
        zgradeTable = table;
        selectedIndex = index;
        etnoviNaziv.setText(zgrada.getNazivZgrada());
    }

    public void sacuvajClicked(){
        String naziv = etnoviNaziv.getText();
        for (Zgrada e : list) {
            if((naziv.compareTo(e.getNazivZgrada())) == 0) {
                DBConnector.showAlert("Zgrade", "Zgrada vec postoji!");
                return;
            }
        }
        try {
            Connection conn = DBConnector.getConnection();
            String query = "UPDATE zgrada SET nazivZgrada = ? WHERE idZgrada = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, naziv);
            ps.setInt(2, zgrada.getIdZgrada());
            if(ps.executeUpdate()>0) {
                DBConnector.showAlert("Zgrade", "Sacuvano!");
                conn.close();
                zgrada.setNazivZgrada(naziv);
                list.set(selectedIndex, zgrada);
                Stage stage = (Stage) etnoviNaziv.getScene().getWindow();
                stage.close();
                zgradeTable.refresh();
            }
            else
                DBConnector.showAlert("Zgrade", "Greska!");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

}
