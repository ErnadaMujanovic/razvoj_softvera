package main;

import javafx.fxml.Initializable;

public class Predmet{

    private Integer idPredmet;
    private String nazivPredmet, sifraPredmet;
    private Korisnik nosioc;
    private Semestar semestar;

    public Predmet(){}

    public Predmet(Integer idPredmet, String nazivPredmet, String sifraPredmet, Korisnik nosioc, Semestar semestar){
        this.idPredmet = idPredmet;
        this.nazivPredmet = nazivPredmet;
        this.sifraPredmet = sifraPredmet;
        this.nosioc = nosioc;
        this.semestar = semestar;
    }

    public int getIdPredmet() {
        return idPredmet;
    }

    public void setIdPredmet(int idPredmet) {
        this.idPredmet = idPredmet;
    }

    public String getNazivPredmet() {
        return nazivPredmet;
    }

    public void setNazivPredmet(String nazivPredmet) {
        this.nazivPredmet = nazivPredmet;
    }

    public String getSifraPredmet() {
        return sifraPredmet;
    }

    public void setSifraPredmet(String sifraPredmet) {
        this.sifraPredmet = sifraPredmet;
    }

    public Korisnik getNosioc() {
        return nosioc;
    }

    public void setNosioc(Korisnik nosioc) {
        this.nosioc = nosioc;
    }

    public Semestar getSemestar() {
        return semestar;
    }

    public void setSemestar(Semestar semestar) {
        this.semestar = semestar;
    }

    @Override
    public String toString() {
        return nazivPredmet;
    }

}
