package main;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class NastavnikController {

    private static Korisnik nastavnik;

    public void recieveInfoFromLogin(Korisnik nastavnik){
        this.nastavnik = nastavnik;
    }

    public void btnRezervacijeClicked(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("rezervacije.fxml"));
        Parent root = loader.load();
        RezervacijeController controller = loader.getController();
        controller.recieveInfoFromLogin(nastavnik);
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan - rezervacije");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }



    public void btnIzvjestajClicked(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("izvjestaj.fxml"));
        Parent root = loader.load();
        IzvjestajController controller = loader.getController();
        controller.receiveInfofromKorisnik(nastavnik);
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Nastavnik - izvjestaj");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();

    }

    @FXML
    public void rasporedButtonClicked(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("raspored.fxml"));
        Parent root = loader.load();
        RasporedController controller = loader.getController();
        controller.receiveInfofromKorisnik(nastavnik);
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Raspored");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    public void odjavaClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan - grupe");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }



}
