package main;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.sql.*;


public class LoginController {

    @FXML
    private TextField txtUsername;
    @FXML
    private PasswordField txtPassword;
    @FXML
    private Button btnLogin;
    @FXML
    private Button btnStudent;

    @FXML
    public void loginButtonClicked(ActionEvent event){
        try{
            Connection conn = DBConnector.getConnection();

            String username = txtUsername.getText();
            String password = txtPassword.getText();

            String checkUser = "SELECT * FROM korisnik WHERE korIme = ? AND korSifra = ?";
            PreparedStatement stmt = conn.prepareStatement(checkUser);
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if(!rs.next()) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Login");
                alert.setHeaderText(null);
                alert.setContentText("Pogresan username / password!");
                alert.showAndWait();
            }
            else{
                Korisnik korisnik = new Korisnik(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
                                                 rs.getString(5), rs.getBoolean(6), rs.getBoolean(7), rs.getBoolean(8));

                rs.close();
                stmt.close();
                conn.close();

                FXMLLoader loader;
                Parent root;

                if(korisnik.isProdekan()){
                    loader = new FXMLLoader(getClass().getResource("prodekan.fxml"));
                    root = loader.load();

                    ProdekanController prodekanController = loader.getController();
                    prodekanController.recieveInfoFromLogin(korisnik);
                }else{
                    loader = new FXMLLoader(getClass().getResource("nastavnik.fxml"));
                    root = loader.load();

                    NastavnikController nastavnikController = loader.getController();
                    nastavnikController.recieveInfoFromLogin(korisnik);
                }

                Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.setResizable(false);
                stage.show();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void studentButtonClicked(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("raspored.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
        stage.getScene().getWindow().centerOnScreen();
    }
}
