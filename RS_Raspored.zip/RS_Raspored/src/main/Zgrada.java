package main;

public class Zgrada {

    private Integer idZgrada;
    private String nazivZgrada;

    public Zgrada(){}

    public Zgrada(Integer idZgrada, String nazivZgrada){
        this.idZgrada = idZgrada;
        this.nazivZgrada = nazivZgrada;
    }

    public int getIdZgrada() {
        return idZgrada;
    }

    public void setIdZgrada(int idZgrada) {
        this.idZgrada = idZgrada;
    }

    public String getNazivZgrada() {
        return nazivZgrada;
    }

    public void setNazivZgrada(String nazivZgrada) {
        this.nazivZgrada = nazivZgrada;
    }

    @Override
    public String toString() {
        return nazivZgrada;
    }
}
