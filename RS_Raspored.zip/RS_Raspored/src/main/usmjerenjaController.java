package main;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class usmjerenjaController implements Initializable {
    @FXML
    private TableView<Usmjerenje> tableUsmjerenja;
    @FXML
    private TableColumn<Usmjerenje, String> colSifUsmjerenje;
    @FXML
    private TableColumn<Usmjerenje, String> colNazivUsmjerenje;
    @FXML
    private TextField etSifUsmjerenje;
    @FXML
    private TextField etNazivUsmjerenje;

    ObservableList<Usmjerenje> listUsmjerenja = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM usmjerenje");
            while (rs.next()) {
                listUsmjerenja.add(new Usmjerenje(rs.getInt("idUsmjerenje"), rs.getString("sifraUsmjerenje"), rs.getString("nazivUsmjerenje")));
            }
            rs.close();
            conn.close();
            colSifUsmjerenje.setCellValueFactory(new PropertyValueFactory<>("sifraUsmjerenje"));
            colNazivUsmjerenje.setCellValueFactory(new PropertyValueFactory<>("nazivUsmjerenje"));
            tableUsmjerenja.setItems(listUsmjerenja);

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dodajButtonClicked(){
        if(etSifUsmjerenje.getText().trim().isEmpty()){
            DBConnector.showAlert("Usmjerenja","Molimo unesite sifru usmjerenja!");
            etSifUsmjerenje.requestFocus();
            return;
        }
        if(etNazivUsmjerenje.getText().trim().isEmpty()){
            DBConnector.showAlert("Usmjerenja","Molimo unesite naziv usmjerenja!");
            etNazivUsmjerenje.requestFocus();
            return;
        }
        String sifUsmjerenje = etSifUsmjerenje.getText();
        String nazivUsmjerenje = etNazivUsmjerenje.getText();

        for(Usmjerenje e : listUsmjerenja){
            if(sifUsmjerenje.compareTo(e.getSifraUsmjerenje())==0 || nazivUsmjerenje.compareTo(e.getNazivUsmjerenje())==0){
                DBConnector.showAlert("Usmjerenja","Usmjerenje vec postoji!");
                return;
            }
        }
        try {
            Connection conn = DBConnector.getConnection();
            String query = "INSERT INTO usmjerenje (sifraUsmjerenje, nazivUsmjerenje) VALUES (?,?) ";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, sifUsmjerenje);
            ps.setString(2, nazivUsmjerenje);
            if(ps.executeUpdate()>0) {
                DBConnector.showAlert("Usmjerenja","Unos uspjesan!");
                if(!listUsmjerenja.isEmpty())
                    listUsmjerenja.add(new Usmjerenje(listUsmjerenja.get(listUsmjerenja.size()-1).getIdUsmjerenje()+1, sifUsmjerenje, nazivUsmjerenje));
                else
                    listUsmjerenja.add(new Usmjerenje(1, sifUsmjerenje, nazivUsmjerenje));
                tableUsmjerenja.refresh();
                conn.close();
                etSifUsmjerenje.clear();
                etNazivUsmjerenje.clear();
            }
            else {
                DBConnector.showAlert("Usmjerenja","Greska!");
                etNazivUsmjerenje.clear();
                etSifUsmjerenje.clear();
            }

        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void buttonObrisiClicked(){
        Usmjerenje odabranoUsmjerenje  = tableUsmjerenja.getSelectionModel().getSelectedItem();
        if(odabranoUsmjerenje == null) {
            DBConnector.showAlert("Usmjerenja","Molimo odaberite usmjerenje!");
            return;
        }
        int selectedIndex = tableUsmjerenja.getSelectionModel().getFocusedIndex();

        try {
            if(odabranoUsmjerenje.getIdUsmjerenje() == listUsmjerenja.get(listUsmjerenja.size()-1).getIdUsmjerenje()){
                Connection conn = DBConnector.getConnection();
                String query = "DELETE FROM usmjerenje WHERE idUsmjerenje = ? ";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setInt(1, odabranoUsmjerenje.getIdUsmjerenje());
                if(ps.executeUpdate()>0) {
                    listUsmjerenja.remove(selectedIndex);
                    PreparedStatement preparedStatement = conn.prepareStatement("ALTER TABLE usmjerenje AUTO_INCREMENT = ?");
                    if(listUsmjerenja.size() > 1)
                        preparedStatement.setInt(1, listUsmjerenja.get(listUsmjerenja.size()-1).getIdUsmjerenje());
                    else
                        preparedStatement.setInt(1, 1);
                    preparedStatement.executeUpdate();
                    DBConnector.showAlert("Usmjerenja", "Brisanje uspjesno!");
                    tableUsmjerenja.refresh();
                    conn.close();
                }
                else {
                    DBConnector.showAlert("Usmjerenja", "Greska!");
                    conn.close();
                }

            }

            else {

                Connection conn = DBConnector.getConnection();
                String query = "DELETE FROM usmjerenje WHERE idUsmjerenje = ? ";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setInt(1, odabranoUsmjerenje.getIdUsmjerenje());
                if(ps.executeUpdate()>0) {
                    DBConnector.showAlert("Usmjerenja", "Brisanje uspjesno!");
                    listUsmjerenja.remove(selectedIndex);
                    tableUsmjerenja.refresh();
                    conn.close();
                 }
                else {
                    DBConnector.showAlert("Usmjerenja", "Greska!");
                    conn.close();
                }

            }
            etSifUsmjerenje.clear();
            etNazivUsmjerenje.clear();

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void urediUsmjerenjeClicked() throws IOException{
        Usmjerenje selectedUsmjerenje = tableUsmjerenja.getSelectionModel().getSelectedItem();
        int selectedIndex = tableUsmjerenja.getSelectionModel().getFocusedIndex();
        if(selectedUsmjerenje == null) {
            DBConnector.showAlert("Usmjerenja", "Molimo odaberite usmjerenje!");
            return;
        }
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("usmjerenjeUredi.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        urediUsmjerenjeController urediController = fxmlLoader.getController();
        urediController.recieveInfoFromUsmjerenja(selectedUsmjerenje,selectedIndex,listUsmjerenja,tableUsmjerenja);
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Uredi usmjerenje");
        stage.setResizable(false);
        stage.setScene(new Scene(root1));
        stage.show();
    }

    public void btnNazadClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("prodekan.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }
}
