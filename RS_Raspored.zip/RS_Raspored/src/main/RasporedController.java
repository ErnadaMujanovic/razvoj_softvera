package main;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class RasporedController implements Initializable {
    static class parameterPair {
        private int count = 0;
        private int position = 0;
        public parameterPair(){
            this.count = 0;
            this.position = 0;
        }
        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        public int getPosition() {
            return position;
        }

        public void setPosition(int position) {
            this.position = position;
        }
    }

    private Korisnik korisnik;
    @FXML
    private Text ponDatum, utoDatum, sriDatum, cetDatum, petDatum, subDatum;
    @FXML
    private ComboBox<String> tip, nastavnik, zgrada, sala, usmjerenje, godina, predmet, grupa, vrsta;
    @FXML
    private Button prethodna, sledecea;
    @FXML
    private Pane ponPane, utoPane, sriPane, cetPane, petPane, subPane;

    private LocalDate pocSedmice, krajSedmice;

    private String tipCH = null, nastavnikCH = null, zgradaCH = null, salaCH = null, usmjerenjeCH = null, godinaCH = null, predmetCH = null, grupaCH = null, vrstaCH = null;

    private HashMap<LocalDate, ArrayList<Rezervacija>> mapaRezervacija = new HashMap<>();

    private HashMap<String, ArrayList<Rezervacija>> mapaCasovi = new HashMap<>();

    private String queryExtension = "";

    final private int paneWidth = 186, hourHeight = 576/12;


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private String generateQuery(String q1, String q2, String atrb, String alias){
        if(alias != null){
            if (tipCH == null && usmjerenjeCH == null && godinaCH == null && predmetCH == null && grupaCH == null && vrstaCH == null)
                return "SELECT DISTINCT " + atrb + q1 + " UNION " + "SELECT DISTINCT " + atrb + q2 + " ORDER BY " + alias;
            else if (tipCH.equals("cas") || tipCH.equals("nadoknada") || usmjerenjeCH != null || godinaCH != null || predmetCH != null || grupaCH != null || vrstaCH != null)
                return "SELECT DISTINCT " + atrb + q1 + " ORDER BY " + alias;
            else
                return "SELECT DISTINCT " + atrb + q2 + " ORDER BY " + alias;
        }else {
            if (tipCH == null && usmjerenjeCH == null && godinaCH == null && predmetCH == null && grupaCH == null && vrstaCH == null)
                return "SELECT DISTINCT " + atrb + q1 + " UNION " + "SELECT DISTINCT " + atrb + q2 + " ORDER BY " + atrb;
            else if (tipCH.equals("cas") || tipCH.equals("nadoknada") || usmjerenjeCH != null || godinaCH != null || predmetCH != null || grupaCH != null || vrstaCH != null)
                return "SELECT DISTINCT " + atrb + q1 + " ORDER BY " + atrb;
            else
                return "SELECT DISTINCT " + atrb + q2 + " ORDER BY " + atrb;
        }
    }

    public void updateInputs(){

        System.out.println("PROSOOOOOOOOOOO 1");

        if(tipCH == null) {
            tipCH = (String) tip.getValue();
            if(tipCH == null)
                tip.setDisable(false);
            else
                tip.setDisable(true);
        }else
            tip.setDisable(true);

        if(nastavnikCH == null) {
            if(tipCH == null)
                nastavnik.setDisable(true);
            else {
                nastavnikCH = (String) nastavnik.getValue();
                if (nastavnikCH == null)
                    nastavnik.setDisable(false);
                else
                    nastavnik.setDisable(true);
            }
        }else
            nastavnik.setDisable(true);

        if(zgradaCH == null) {
            if(tipCH == null)
                zgrada.setDisable(true);
            else {
                zgradaCH = (String) zgrada.getValue();
                if (zgradaCH == null)
                    zgrada.setDisable(false);
                else
                    zgrada.setDisable(true);
            }
        }else
            zgrada.setDisable(true);

        if(salaCH == null) {
            if(tipCH == null)
                sala.setDisable(true);
            else {
                salaCH = (String) sala.getValue();
                if (salaCH == null)
                    sala.setDisable(false);
                else
                    sala.setDisable(true);
            }
        }else
            sala.setDisable(true);

        if(usmjerenjeCH == null) {
            if(tipCH == null)
                usmjerenje.setDisable(true);
            else {
                usmjerenjeCH = (String) usmjerenje.getValue();
                if (usmjerenjeCH == null)
                    usmjerenje.setDisable(false);
                else
                    usmjerenje.setDisable(true);
            }
        }else
            usmjerenje.setDisable(true);

        if(godinaCH == null) {
            if(tipCH == null)
                godina.setDisable(true);
            else {
                godinaCH = (String) godina.getValue();
                if (godinaCH == null)
                    godina.setDisable(false);
                else
                    godina.setDisable(true);
            }
        }else
            godina.setDisable(true);

        if(predmetCH == null) {
            if(tipCH == null)
                predmet.setDisable(true);
            else {
                predmetCH = (String) predmet.getValue();
                if (predmetCH == null)
                    predmet.setDisable(false);
                else
                    predmet.setDisable(true);
            }
        }else
            predmet.setDisable(true);

        if(grupaCH == null) {
            if(tipCH == null)
                grupa.setDisable(true);
            else {
                grupaCH = (String) grupa.getValue();
                if (grupaCH == null)
                    grupa.setDisable(false);
                else
                    grupa.setDisable(true);
            }
        }else
            grupa.setDisable(true);

        if(vrstaCH == null) {
            if(tipCH == null)
                vrsta.setDisable(true);
            else {
                vrstaCH = (String) vrsta.getValue();
                if (vrstaCH == null)
                    vrsta.setDisable(false);
                else
                    vrsta.setDisable(true);
            }
        }else
            vrsta.setDisable(true);


        System.out.println("PROSOOOOOOOOOOO 3");

        String query1 = " FROM rezervacija" +
                " INNER JOIN sala ON rezervacija.idSala = sala.idSala" +
                " INNER JOIN zgrada ON sala.idZgrada = zgrada.idZgrada" +
                " INNER JOIN grupa ON rezervacija.idGrupa = grupa.idGrupa" +
                " INNER JOIN korisnik AS predavac ON grupa.idNastavnik = predavac.idKorisnik" +
                " INNER JOIN predmet ON grupa.idPredmet = predmet.idPredmet" +
                " INNER JOIN predmeti ON predmeti.idPredmet = predmet.idPredmet" +
                " INNER JOIN usmjerenje ON predmeti.idUsmjerenje = usmjerenje.idUsmjerenje";
        String query2 = " FROM rezervacija" +
                " INNER JOIN korisnik as rezervator ON rezervacija.idKorisnik = rezervator.idKorisnik" +
                " INNER JOIN sala ON rezervacija.idSala = sala.idSala" +
                " INNER JOIN zgrada ON sala.idZgrada = zgrada.idZgrada";

        int i = 0;
        queryExtension = "";
        System.out.println("PROSOOOOOOOOOOO 4");
        if (tipCH != null) {
            queryExtension += " WHERE tip = " + "\"" + tipCH + "\"";
            ++i;
        }
        System.out.println("PROSOOOOOOOOOOO 5");
        if (nastavnikCH != null) {
            Scanner s = new Scanner(nastavnikCH);
            String ime = s.next();
            String prezime = s.next();

            if (i != 0) {
                if(tipCH.equals("cas"))
                    queryExtension += " AND predavac.imeKorisnik = " + "\"" + ime + "\"" + " AND predavac.prezKorisnik = " + "\"" + prezime + "\"";
                else
                    queryExtension += " AND rezervator.imeKorisnik = " + "\"" + ime + "\"" + " AND rezervator.prezKorisnik = " + "\"" + prezime + "\"";
            }
            else {
                if(tipCH.equals("cas"))
                    queryExtension += " WHERE predavac.imeKorisnik = " + "\"" + ime + "\"" + " AND predavac.prezKorisnik = " + "\"" + prezime + "\"";
                else
                    queryExtension += " WHERE rezervator.imeKorisnik = " + "\"" + ime + "\"" + " AND rezervator.prezKorisnik = " + "\"" + prezime + "\"";
            }
            ++i;
        }
        System.out.println("PROSOOOOOOOOOOO 6");
        if (zgradaCH != null) {
            if (i != 0) {
                queryExtension += " AND nazivZgrada = " + "\"" + zgradaCH + "\"";
            }
            else {
                queryExtension += " WHERE nazivZgrada = " + "\"" + zgradaCH + "\"";
            }
            ++i;
        }
        System.out.println("PROSOOOOOOOOOOO 7");
        if (salaCH != null) {
            if (i != 0) {
                queryExtension += " AND sifraSala = " + "\"" + salaCH + "\"";
            }
            else {
                queryExtension += " WHERE sifraSala = " + "\"" + salaCH + "\"";
            }
            ++i;
        }
        System.out.println("PROSOOOOOOOOOOO 8");
        if (usmjerenjeCH != null) {
            if (i != 0) {
                queryExtension += " AND sifraUsmjerenje = " + "\"" + usmjerenjeCH + "\"";
            }
            else {
                queryExtension += " WHERE sifraUsmjerenje = " + "\"" + usmjerenjeCH + "\"";
            }
            ++i;
        }
        System.out.println("PROSOOOOOOOOOOO 9");
        if (godinaCH != null) {
            if (i != 0) {
                queryExtension += " AND godinaStudija = " + godinaCH;
            }
            else {
                queryExtension += " WHERE godinaStudija = " + godinaCH;
            }
            ++i;
        }
        System.out.println("PROSOOOOOOOOOOO 10");
        if (predmetCH != null) {
            if (i != 0) {
                queryExtension += " AND nazivPredmet = " + "\"" + predmetCH + "\"";
            }
            else {
                queryExtension += " WHERE nazivPredmet = " + "\"" + predmetCH + "\"";
            }
            ++i;
        }
        System.out.println("PROSOOOOOOOOOOO 11");
        if (grupaCH != null) {
            if (i != 0) {
                queryExtension += " AND sifraGrupa = " + "\"" + grupaCH + "\"";
            }
            else {
                queryExtension += " WHERE sifraGrupa = " + "\"" + grupaCH + "\"";
            }
            ++i;
        }
        System.out.println("PROSOOOOOOOOOOO 11");
        if (vrstaCH != null) {
            if (i != 0) {
                queryExtension += " AND vrsta = " + "\"" + vrstaCH + "\"";
            }
            else {
                queryExtension += " WHERE vrsta = " + "\"" + vrstaCH + "\"";
            }
            ++i;
        }

        query1 += queryExtension;
        query2 += queryExtension;

        System.out.println("PROSOOOOOOOOOOO 12");

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/raspored?useUnicode=true&characterEncoding=utf8&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=Europe/Zagreb", "root", "root");
            Statement stmt = conn.createStatement();
            ResultSet rs;

            System.out.println("TIP");
            System.out.println("");
            if(tipCH == null) {
                tip.getItems().clear();
                tip.setValue(null);
                rs = stmt.executeQuery(generateQuery(query1, query2, "tip", null));
                while (rs.next()) {
                    tip.getItems().add(rs.getString(1));
                    System.out.println(rs.getString(1));
                }
            }

            System.out.println("NASTAVNIK");
            System.out.println("");
            if(nastavnikCH == null && tipCH != null) {
                nastavnik.getItems().clear();
                nastavnik.setValue(null);
                if(tipCH.equals("cas"))
                    rs = stmt.executeQuery(generateQuery(query1, query2, "CONCAT(predavac.imeKorisnik, \" \", predavac.prezKorisnik) AS imePrezime", "imePrezime"));
                else
                    rs = stmt.executeQuery(generateQuery(query1, query2, "CONCAT(rezervator.imeKorisnik, \" \", rezervator.prezKorisnik) AS imePrezime", "imePrezime"));
                while (rs.next()) {
                    nastavnik.getItems().add(rs.getString(1));
                    System.out.println(rs.getString(1));
                }
            }

            System.out.println("ZGRADA");
            System.out.println("");
            if(zgradaCH == null && tipCH != null) {
                zgrada.getItems().clear();
                zgrada.setValue(null);
                rs = stmt.executeQuery(generateQuery(query1, query2, "nazivZgrada", null));
                while (rs.next()) {
                    zgrada.getItems().add(rs.getString(1));
                    System.out.println(rs.getString(1));
                }
            }

            System.out.println("SALA");
            System.out.println("");
            if(salaCH == null && tipCH != null) {
                sala.getItems().clear();
                sala.setValue(null);
                rs = stmt.executeQuery(generateQuery(query1, query2, "sifraSala", null));
                while (rs.next()) {
                    sala.getItems().add(rs.getString(1));
                    System.out.println(rs.getString(1));
                }
            }


            if (tipCH != null && !tipCH.equals("diplomski") && !tipCH.equals("magistarski") && !tipCH.equals("doktorat") && !tipCH.equals("simpozij")) {
                System.out.println("USMJERENJE");
                System.out.println("");
                if(usmjerenjeCH == null && tipCH != null) {
                    usmjerenje.getItems().clear();
                    usmjerenje.setValue(null);
                    rs = stmt.executeQuery("SELECT DISTINCT sifraUsmjerenje" + query1 + " ORDER BY " + "sifraUsmjerenje");
                    while (rs.next()) {
                        usmjerenje.getItems().add(rs.getString(1));
                        System.out.println(rs.getString(1));
                    }
                }

                System.out.println("GODINA");
                System.out.println("");
                if(godinaCH == null && tipCH != null) {
                    godina.getItems().clear();
                    godina.setValue(null);
                    rs = stmt.executeQuery("SELECT DISTINCT godinaStudija" + query1 + " ORDER BY " + "godinaStudija");
                    while (rs.next()) {
                        godina.getItems().add(rs.getString(1));
                        System.out.println(rs.getString(1));
                    }
                }

                System.out.println("PREDMET");
                System.out.println("");
                if(predmetCH == null && tipCH != null) {
                    predmet.getItems().clear();
                    predmet.setValue(null);
                    rs = stmt.executeQuery("SELECT DISTINCT nazivPredmet" + query1 + " ORDER BY " + "nazivPredmet");
                    while (rs.next()) {
                        predmet.getItems().add(rs.getString(1));
                        System.out.println(rs.getString(1));
                    }
                }

                System.out.println("GRUPA");
                System.out.println("");
                if(grupaCH == null && tipCH != null) {
                    grupa.getItems().clear();
                    grupa.setValue(null);
                    rs = stmt.executeQuery("SELECT DISTINCT sifraGrupa" + query1 + " ORDER BY " + "sifraGrupa");
                    while (rs.next()) {
                        grupa.getItems().add(rs.getString(1));
                        System.out.println(rs.getString(1));
                    }
                }

                System.out.println("VRSTA");
                System.out.println("");
                if(vrstaCH == null && tipCH != null) {
                    vrsta.getItems().clear();
                    vrsta.setValue(null);
                    rs = stmt.executeQuery("SELECT DISTINCT vrsta" + query1 + " ORDER BY " + "vrsta");
                    while (rs.next()) {
                        vrsta.getItems().add(rs.getString(1));
                        System.out.println(rs.getString(1));
                    }
                }
            }
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("PROSOOOOOOOOOOO 13");
    }

    public void resetFilters() {

        tipCH = null;
        nastavnikCH = null;
        zgradaCH = null;
        salaCH = null;
        usmjerenjeCH = null;
        godinaCH = null;
        predmetCH = null;
        grupaCH = null;
        vrstaCH = null;

        tip.getItems().clear();
        nastavnik.getItems().clear();
        zgrada.getItems().clear();
        sala.getItems().clear();
        usmjerenje.getItems().clear();
        godina.getItems().clear();
        predmet.getItems().clear();
        grupa.getItems().clear();
        vrsta.getItems().clear();

        tip.setValue(null);
        nastavnik.setValue(null);
        zgrada.setValue(null);
        sala.setValue(null);
        usmjerenje.setValue(null);
        godina.setValue(null);
        predmet.setValue(null);
        grupa.setValue(null);
        vrsta.setValue(null);

        queryExtension = "";
        updateInputs();
    }


    private void loadReservations(){
        mapaRezervacija.clear();
        mapaCasovi.clear();

        String query = "SELECT DISTINCT datum, pocetak, kraj, tip, sifraSala, nazivZgrada, rezervator.imeKorisnik, rezervator.prezKorisnik, sifraGrupa, vrsta, predavac.imeKorisnik, predavac.prezKorisnik, nazivPredmet, sifraPredmet, dan FROM rezervacija" +
                       " LEFT JOIN sala ON rezervacija.idSala = sala.idSala" +
                       " LEFT JOIN zgrada ON sala.idZgrada = zgrada.idZgrada" +
                       " LEFT JOIN grupa ON rezervacija.idGrupa = grupa.idGrupa" +
                       " LEFT JOIN korisnik AS predavac ON grupa.idNastavnik = predavac.idKorisnik" +
                       " LEFT JOIN predmet ON grupa.idPredmet = predmet.idPredmet" +
                       " LEFT JOIN predmeti ON predmeti.idPredmet = predmet.idPredmet" +
                       " LEFT JOIN usmjerenje ON predmeti.idUsmjerenje = usmjerenje.idUsmjerenje" +
                       " LEFT JOIN korisnik AS rezervator ON rezervator.idKorisnik = rezervacija.idKorisnik" +
                       queryExtension +
                       " ORDER BY datum";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/raspored?useUnicode=true&characterEncoding=utf8&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=Europe/Zagreb", "root", "root");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while(rs.next()){
                Date datum = rs.getDate(1);
                Time pocetak = rs.getTime(2);
                Time kraj = rs.getTime(3);
                String tip = rs.getString(4);
                String sifraSala = rs.getString(5);
                String nazivZgrada = rs.getString(6);
                String rezervatorIme = rs.getString(7);
                String rezervatorPrezime = rs.getString(8);
                String sifraGrupa = rs.getString(9);
                String vrsta = rs.getString(10);
                String predavacIme = rs.getString(11);
                String predavacPrezime = rs.getString(12);
                String nazivPredmet = rs.getString(13);
                String sifraPredmet = rs.getString(14);
                String dan = rs.getString(15);

                Zgrada zgrada = new Zgrada(null, nazivZgrada);
                Sala sala = new Sala(null, zgrada, sifraSala);
                Korisnik rezervator = new Korisnik(null, null, null, rezervatorIme, rezervatorPrezime, null, null, null);
                Predmet predmet = new Predmet(null, nazivPredmet, sifraPredmet, null,  null);
                Korisnik predavac = new Korisnik(null, null, null, predavacIme, predavacPrezime, null, null, null);
                Grupa grupa = new Grupa(null, predmet, predavac, sifraGrupa, vrsta);
                Rezervacija rezervacija = new Rezervacija(null, datum, pocetak, kraj, tip, sala, rezervator, grupa, dan);

                if(tipCH.equals("cas")) {
                    if (mapaCasovi.containsKey(dan)) {
                        mapaCasovi.get(dan).add(rezervacija);
                    } else {
                        mapaCasovi.put(dan, new ArrayList<Rezervacija>());
                        mapaCasovi.get(dan).add(rezervacija);
                    }
                }else {
                    if (mapaRezervacija.containsKey(datum.toLocalDate())) {
                        mapaRezervacija.get(datum.toLocalDate()).add(rezervacija);
                    } else {
                        mapaRezervacija.put(datum.toLocalDate(), new ArrayList<Rezervacija>());
                        mapaRezervacija.get(datum.toLocalDate()).add(rezervacija);
                    }
                }
            }
            rs.close();
            stmt.close();
            conn.close();

            if(tipCH.equals("cas")) {
                for (Map.Entry<LocalDate, ArrayList<Rezervacija>> set : mapaRezervacija.entrySet()) {
                    System.out.println(set.getKey());
                    ArrayList<Rezervacija> lista = set.getValue();
                    for (int i = 0; i < lista.size(); ++i)
                        System.out.println(lista.get(i).getPocetak() + "  " + lista.get(i).getKraj() + " " + (lista.get(i).getPocetak().getHours() - 8));
                }
            }else{
                for (Map.Entry<String, ArrayList<Rezervacija>> set : mapaCasovi.entrySet()) {
                    System.out.println(set.getKey());
                    ArrayList<Rezervacija> lista = set.getValue();
                    for (int i = 0; i < lista.size(); ++i)
                        System.out.println(lista.get(i).getPocetak() + "  " + lista.get(i).getKraj() + " " + (lista.get(i).getPocetak().getHours() - 8));
                }
            }

        } catch (Exception e){
            e.printStackTrace();
        }

    }

    @FXML
    public void draw(){
        ponPane.getChildren().clear();
        utoPane.getChildren().clear();
        sriPane.getChildren().clear();
        cetPane.getChildren().clear();
        petPane.getChildren().clear();
        subPane.getChildren().clear();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        ponDatum.setText(formatter.format(pocSedmice));
        utoDatum.setText(formatter.format(pocSedmice.plusDays(1)));
        sriDatum.setText(formatter.format(pocSedmice.plusDays(2)));
        cetDatum.setText(formatter.format(pocSedmice.plusDays(3)));
        petDatum.setText(formatter.format(pocSedmice.plusDays(4)));
        subDatum.setText(formatter.format(pocSedmice.plusDays(5)));

        if(tipCH == null){
            DBConnector.showAlert("Upozorenje", "Morate unijeti tip rezervacije :)");
            return;
        }

        loadReservations();

        if(tipCH.equals("cas")){
            drawDayCas("ponedeljak", ponPane);
            drawDayCas("utorak", utoPane);
            drawDayCas("srijeda", sriPane);
            drawDayCas("cetvrtak", cetPane);
            drawDayCas("petak", petPane);
            drawDayCas("subota", subPane);
        }else{
            drawDayRes(pocSedmice, ponPane);
            drawDayRes(pocSedmice.plusDays(1), utoPane);
            drawDayRes(pocSedmice.plusDays(2), sriPane);
            drawDayRes(pocSedmice.plusDays(3), cetPane);
            drawDayRes(pocSedmice.plusDays(4), petPane);
            drawDayRes(pocSedmice.plusDays(5), subPane);
        }
    }

    private void drawDayRes(LocalDate date, Pane pane){
        if(mapaRezervacija.containsKey(date)) {
            ArrayList<parameterPair> lookup = new ArrayList<>(12);
            for(int i = 0; i < 12; ++i)
                lookup.add(new parameterPair());

            ArrayList<Rezervacija> lista = mapaRezervacija.get(date);
            for (int i = 0; i < lista.size(); ++i) {
                int start = lista.get(i).getPocetak().getHours() - 8;
                int end = lista.get(i).getKraj().getHours() - 8;
                for (int j = start; j < end; ++j) {
                    lookup.get(j).count++;
                }
            }

            for (int i = 0; i < lista.size(); ++i){
                int start = lista.get(i).getPocetak().getHours() - 8;
                int end = lista.get(i).getKraj().getHours() - 8;
                int position = 0;
                int count = 0;

                for (int j = start; j < end; ++j) {
                    if(lookup.get(j).count > count)
                        count = lookup.get(j).count;
                    if(lookup.get(j).position > position)
                        position = lookup.get(j).position;
                }

                Rezervacija rez = lista.get(i);
                Button btn = new Button();
                String info = rez.getKorisnik().getImeKorisnik() + "\n" + rez.getKorisnik().getPrezKorisnik() + "\n" + rez.getTip() + "\n" + rez.getSala().getZgrada().getNazivZgrada() + "\n" + rez.getSala().getSifraSala();
                btn.setText(info);
                btn.setLayoutX(position);
                btn.setLayoutY(start*hourHeight);
                btn.setPrefHeight((end-start)*hourHeight);
                btn.setPrefWidth((paneWidth-position)/count);
                btn.setStyle("-fx-background-color: #99A3A4; -fx-border-color: #C0C0C0;");
                btn.setTextAlignment(TextAlignment.CENTER);
                pane.getChildren().add(btn);


                for (int j = start; j < end; ++j) {
                    lookup.get(j).position = position + (paneWidth-position)/count;
                    lookup.get(j).count--;
                }
            }
        }
    }

    private void drawDayCas(String day, Pane pane){
        if(mapaCasovi.containsKey(day)) {
            ArrayList<parameterPair> lookup = new ArrayList<>(12);
            for(int i = 0; i < 12; ++i)
                lookup.add(new parameterPair());

            ArrayList<Rezervacija> lista = mapaCasovi.get(day);
            for (int i = 0; i < lista.size(); ++i) {
                int start = lista.get(i).getPocetak().getHours() - 8;
                int end = lista.get(i).getKraj().getHours() - 8;
                for (int j = start; j < end; ++j) {
                    lookup.get(j).count++;
                }
            }

            for (int i = 0; i < lista.size(); ++i){
                int start = lista.get(i).getPocetak().getHours() - 8;
                int end = lista.get(i).getKraj().getHours() - 8;
                int position = 0;
                int count = 0;

                for (int j = start; j < end; ++j) {
                    if(lookup.get(j).count > count)
                        count = lookup.get(j).count;
                    if(lookup.get(j).position > position)
                        position = lookup.get(j).position;
                }

                Rezervacija rez = lista.get(i);
                Button btn = new Button();
                String info = rez.getGrupa().getPredmet().getNazivPredmet() + "\n" + rez.getGrupa().getNastavnik().getImeKorisnik() + " " + rez.getGrupa().getNastavnik().getPrezKorisnik() + "\n" + rez.getSala().getZgrada().getNazivZgrada() + "\n" + rez.getSala().getSifraSala() + "\n" + rez.getGrupa().getSifraGrupa();
                btn.setText(info);
                btn.setLayoutX(position);
                btn.setLayoutY(start*hourHeight);
                btn.setPrefHeight((end-start)*hourHeight);
                btn.setPrefWidth((paneWidth-position)/count);
                if(lista.get(i).getGrupa().getVrsta().equals("P"))
                    btn.setStyle("-fx-background-color: #EC7063 ; -fx-border-color: #C0C0C0;");
                if(lista.get(i).getGrupa().getVrsta().equals("A"))
                    btn.setStyle("-fx-background-color: #5DADE2; -fx-border-color: #C0C0C0;");
                if(lista.get(i).getGrupa().getVrsta().equals("L"))
                    btn.setStyle("-fx-background-color: #58D68D; -fx-border-color: #C0C0C0;");
                btn.setTextAlignment(TextAlignment.CENTER);
                pane.getChildren().add(btn);


                for (int j = start; j < end; ++j) {
                    lookup.get(j).position = position + (paneWidth-position)/count;
                    lookup.get(j).count--;
                }
            }
        }
    }

    @FXML
    public void previousWeek(){
        pocSedmice = pocSedmice.minusDays(7);
        krajSedmice = krajSedmice.minusDays(7);
        draw();
    }

    @FXML
    public void nextWeek(){
        pocSedmice = pocSedmice.plusDays(7);
        krajSedmice = krajSedmice.plusDays(7);
        draw();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("PROSOOOOOOOOOOO");
        pocSedmice = LocalDate.parse("2020-09-21");
        krajSedmice = LocalDate.parse("2020-09-25");

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        ponDatum.setText(formatter.format(pocSedmice));
        utoDatum.setText(formatter.format(pocSedmice.plusDays(1)));
        sriDatum.setText(formatter.format(pocSedmice.plusDays(2)));
        cetDatum.setText(formatter.format(pocSedmice.plusDays(3)));
        petDatum.setText(formatter.format(pocSedmice.plusDays(4)));
        subDatum.setText(formatter.format(pocSedmice.plusDays(5)));

        tipCH = null;
        nastavnikCH = null;
        zgradaCH = null;
        salaCH = null;
        usmjerenjeCH = null;
        godinaCH = null;
        predmetCH = null;
        grupaCH = null;
        vrstaCH = null;


        updateInputs();
    }

    public void receiveInfofromKorisnik (Korisnik nastavnik){
        korisnik = nastavnik;
    }

    public void btnNazadClicked(ActionEvent event) throws IOException {
        Parent root=null;
        if(korisnik == null)
            root = FXMLLoader.load(getClass().getResource("login.fxml"));
        else if(korisnik.isProdekan())
            root = FXMLLoader.load(getClass().getResource("prodekan.fxml"));
        else if(korisnik.isProfesor() || korisnik.isSaradnik())
            root = FXMLLoader.load(getClass().getResource("nastavnik.fxml"));

        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }
}
