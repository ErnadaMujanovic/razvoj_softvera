package main;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class ZgradeController implements Initializable {

    @FXML
    private TableView<Zgrada> tableZgrade;
    @FXML
    private TableColumn<Zgrada, String> nazivZgrada;
    @FXML
    private TextField etNaziv;
    @FXML
    private Button btnDodaj;
    @FXML
    private Button btnNazad;


    ObservableList<Zgrada> oblist = FXCollections.observableArrayList();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM zgrada");

            while (rs.next()) {
                oblist.add(new Zgrada(rs.getInt("idZgrada"), rs.getString("nazivZgrada")));
            }
            rs.close();
            conn.close();

        }
        catch (Exception e) {
            e.printStackTrace();
        }

        nazivZgrada.setCellValueFactory(new PropertyValueFactory<>("nazivZgrada"));

        tableZgrade.setItems(oblist);

    }

    public void OnButtonDodajClicked() {
        if(etNaziv.getText().trim().isEmpty()){
           showZgradeAlert("Molimo unesite naziv zgrade!");
           etNaziv.requestFocus();
           return;
        }
        String naziv = etNaziv.getText();
        for (Zgrada e : oblist) {
            if((naziv.compareTo(e.getNazivZgrada())) == 0) {
                showZgradeAlert("Zgrada vec postoji!");
                return;
            }
        }

            try {
                Connection conn = DBConnector.getConnection();

                String query = "INSERT INTO zgrada (nazivZgrada) VALUES (?) ";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setString(1, naziv);
                if(ps.executeUpdate()>0) {
                    showZgradeAlert("Unos uspjesan!");
                    if(!oblist.isEmpty())
                        oblist.add(new Zgrada(oblist.get(oblist.size()-1).getIdZgrada()+1,naziv));
                    else
                        oblist.add(new Zgrada(1,naziv));
                    tableZgrade.refresh();
                    conn.close();
                }
                else
                    showZgradeAlert("Greska!");
                etNaziv.clear();
            }
            catch (Exception e) {
                e.printStackTrace();
            }


    }

    public void urediZgradeClicked() throws IOException{
        Zgrada selectedZgrada = tableZgrade.getSelectionModel().getSelectedItem();
        int selectedIndex = tableZgrade.getSelectionModel().getFocusedIndex();
        if(selectedZgrada == null) {
            showZgradeAlert("Molimo odaberite zgradu!");
            return;
        }
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("zgradeUredi.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        urediZgradeController urediController = fxmlLoader.getController();
        urediController.recieveInfoFromZgrade(selectedZgrada,oblist,tableZgrade,selectedIndex);
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Uredi zgradu");
        stage.setResizable(false);
        stage.setScene(new Scene(root1));
        stage.show();

    }


    public void btnNazadClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("prodekan.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    public void obrisiZgradeClicked() {
        Zgrada odabranaZgrada = tableZgrade.getSelectionModel().getSelectedItem();
        if(odabranaZgrada == null) {
            showZgradeAlert("Molimo odaberite zgradu!");
            return;
        }
        int selectedIndex = tableZgrade.getSelectionModel().getFocusedIndex();
        if(odabranaZgrada.getIdZgrada() == oblist.get(oblist.size()-1).getIdZgrada()) {

            try {
                Connection conn = DBConnector.getConnection();
                String query = "DELETE FROM zgrada WHERE idZgrada = ? ";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setInt(1, odabranaZgrada.getIdZgrada());
                if(ps.executeUpdate()>0) {
                    oblist.remove(selectedIndex);
                    PreparedStatement preparedStatement = conn.prepareStatement("ALTER TABLE zgrada AUTO_INCREMENT = ?");
                    if(oblist.size() > 1)
                        preparedStatement.setInt(1, oblist.get(oblist.size()-1).getIdZgrada());
                    else
                        preparedStatement.setInt(1, 1);
                    preparedStatement.executeUpdate();
                    showZgradeAlert("Brisanje uspjesno!");
                    tableZgrade.refresh();
                    conn.close();
                }
                else
                    showZgradeAlert("Greska!");
                etNaziv.clear();
            }
            catch (Exception e) {
                e.printStackTrace();
            }


        }
        else {


            try {
                Connection conn = DBConnector.getConnection();
                String query = "DELETE FROM zgrada WHERE idZgrada = ? ";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setInt(1, odabranaZgrada.getIdZgrada());
                if(ps.executeUpdate()>0) {
                    showZgradeAlert("Brisanje uspjesno!");
                    oblist.remove(selectedIndex);
                    tableZgrade.refresh();
                    conn.close();
                }
                else
                    showZgradeAlert("Greska!");
                etNaziv.clear();
            }
            catch (Exception e) {
                e.printStackTrace();
            }

        }

    }

    public void showZgradeAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Zgrade");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }


}
