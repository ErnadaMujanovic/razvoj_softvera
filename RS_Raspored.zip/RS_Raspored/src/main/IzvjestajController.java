package main;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.*;
import java.util.List;


public class  IzvjestajController implements Initializable {


    @FXML
    private ComboBox<String> mjesec;

    ObservableList<String> mjeseci = FXCollections.observableArrayList();
    Korisnik trenutnikor;


    public void nazad(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("nastavnik.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Nastavnik");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    ObservableList<String> listapred = FXCollections.observableArrayList();
    ObservableList<String> datumi = FXCollections.observableArrayList();
    ObservableList<String> vrijeme = FXCollections.observableArrayList();
    String tip;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

           for(int i=1;i<=12;++i){
               mjeseci.add(String.valueOf(i));
           }
        mjesec.setItems(mjeseci);
    }

    public void kreiraj(ActionEvent actionEvent) throws ClassNotFoundException, IOException, SQLException {


        Connection conn1 = null;
            conn1 = DBConnector.getConnection();
            ResultSet rs = conn1.createStatement().executeQuery("SELECT * FROM rezervacija INNER JOIN grupa ON  rezervacija.idGrupa =grupa.idGrupa INNER JOIN predmet ON grupa.idPredmet = predmet.idPredmet INNER JOIN sala ON rezervacija.idSala = sala.idSala WHERE grupa.idNastavnik= " + trenutnikor.getIdKorisnik() + " AND month(datum)=" + mjesec.getValue() + ";");
            while (rs.next()) {
                listapred.add(rs.getString("nazivPredmet"));
                datumi.add(rs.getString("datum"));
                vrijeme.add(rs.getString("sifraSala").concat(" ").concat(rs.getString("pocetak").concat("-").concat(rs.getString("kraj"))));
            }
        ResultSet rs1 = conn1.createStatement().executeQuery("SELECT * FROM korisnik WHERE idKorisnik= " + trenutnikor.getIdKorisnik() + ";");
        while(rs1.next())
            {
           if(rs1.getBoolean(7))
               tip="prof";
           else
               tip="saradnik";

           }


        Document document = new Document();
            try {
                PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("IZVJESTAJ.pdf"));
                document.open();
                document.add(new Paragraph("UNIVERZITET U TUZLI" + "                                                                                 " + "REDOVNI STUDIJ"));
                document.add(new Paragraph("FAKULTET: Fakultet elektrotehnike"));
                document.add(new Paragraph("STUDIJSKI PROGRAM: Elektrotehnika i racunarstvo"));
                document.add(new Paragraph("IZVRŠILAC: " + trenutnikor.getImeKorisnik().concat(" ").concat(trenutnikor.getPrezKorisnik())));
                document.add(new Paragraph("\n\n\n"));
                Paragraph p1 = new Paragraph("IZVJEŠTAJ O ODRŽANOJ NASTAVI/VJEŽBAMA", new Font(Font.FontFamily.HELVETICA, 16, Font.NORMAL, BaseColor.BLACK));
                Paragraph p2 = new Paragraph("za mjesec   " + mjesec.getSelectionModel().getSelectedItem() + "  zimski/ljetni semestar ak.   2020/21  godine ", new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK));
                Paragraph p3 = new Paragraph("(zaokruziti)", new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK));
                p1.setAlignment(Element.ALIGN_CENTER);
                p2.setAlignment(Element.ALIGN_CENTER);
                p3.setAlignment(Element.ALIGN_CENTER);
                document.add(p1);
                document.add(p2);
                document.add(p3);
                document.add(new Paragraph(" "));
                document.add(new Paragraph(" "));
                PdfPTable table = new PdfPTable(6);
                table.setWidthPercentage(105);
                table.setSpacingBefore(10f);
                table.setSpacingAfter(10f);
                float[] colWidth = {3f, 1f, 2.4f, 1f, .3f, .3f};
                table.setWidths(colWidth);
                table.setSpacingAfter(0f);
                PdfPCell col1 = new PdfPCell(new Paragraph("Nastavni predmet(i)", new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)));
                PdfPCell col2 = new PdfPCell(new Paragraph("Datum", new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)));
                PdfPCell col3 = new PdfPCell(new Paragraph("Mjesto i vrijeme\n" + "održavanja\n" + "predavanja/vježbi", new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)));
                PdfPCell col4 = new PdfPCell(new Paragraph("Broj\n" + "prisutnih\n" + "studenata", new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)));
                PdfPCell col5 = new PdfPCell(new Paragraph("P", new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)));
                PdfPCell col6 = new PdfPCell(new Paragraph("V", new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)));
                col1.setHorizontalAlignment(Element.ALIGN_CENTER);
                col2.setHorizontalAlignment(Element.ALIGN_CENTER);
                col3.setHorizontalAlignment(Element.ALIGN_CENTER);
                col4.setHorizontalAlignment(Element.ALIGN_CENTER);
                col5.setHorizontalAlignment(Element.ALIGN_CENTER);
                col6.setHorizontalAlignment(Element.ALIGN_CENTER);
                col1.setVerticalAlignment(Element.ALIGN_MIDDLE);
                col2.setVerticalAlignment(Element.ALIGN_MIDDLE);
                col3.setVerticalAlignment(Element.ALIGN_MIDDLE);
                col4.setVerticalAlignment(Element.ALIGN_MIDDLE);
                col5.setVerticalAlignment(Element.ALIGN_MIDDLE);
                col6.setVerticalAlignment(Element.ALIGN_MIDDLE);

                table.addCell(col1);
                table.addCell(col2);
                table.addCell(col3);
                table.addCell(col4);
                table.addCell(col5);
                table.addCell(col6);

                for (int i = 0; i < listapred.size(); ++i) {
                        table.addCell(listapred.get(i));
                        table.addCell(datumi.get(i));
                        table.addCell(vrijeme.get(i));
                        table.addCell("");
                        if(tip =="prof") {
                            table.addCell("X");
                            table.addCell("");
                        }
                            else{

                                table.addCell(" ");
                                table.addCell("X");

                            }
                        }

                document.add(table);
                document.add(new Paragraph("* Spiskovi studenata nalaze se kod predmetnog nastavnika/saradnika.", new Font(Font.FontFamily.TIMES_ROMAN, 10, Font.NORMAL, BaseColor.BLACK)));
                document.add(new Paragraph(" "));
                document.add(new Paragraph(" "));
                document.add(new Paragraph(" "));
                document.add(new Paragraph("Izvršilac:____________" + "                                                  " + "Prodekan za nastavu:dr.sc.Emir Meskovic"));
                document.add(new Paragraph(" "));
                document.add(new Paragraph("                        " + "                                                                " + "Dekan: dr.sc.Nerdina Mehinovic"));
                document.add(new Paragraph(" "));
                document.add(new Paragraph(" "));
                document.add(new Paragraph("Datum podnošenja zahtjeva: " + java.time.LocalDate.now()));
                document.close();
                writer.close();

            } catch (DocumentException e) {
                e.printStackTrace();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }


            public void receiveInfofromKorisnik (Korisnik nastavnik){
                trenutnikor = nastavnik;
                System.out.println(trenutnikor.getImeKorisnik());
            }
        }



