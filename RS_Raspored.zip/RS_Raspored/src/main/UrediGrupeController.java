package main;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UrediGrupeController {
    @FXML
    private TableView<Grupa> tableGrupe;
    @FXML
    private TableView<Predmet> tablePredmeti;
    @FXML
    private TableColumn<Predmet, String> colNazivPredmet;
    @FXML
    private ListView<Korisnik> lvNastavnik;
    @FXML
    private TextField etPretraziPredmete;
    @FXML
    private TextField etSifGrupa;
    @FXML
    private ComboBox<String> cbVrsta;

    private Grupa selectedGrupa;
    private int selectedIndex;

    ObservableList<Grupa> listGrupe = FXCollections.observableArrayList();
    ObservableList<Predmet> listPredmeti = FXCollections.observableArrayList();
    ObservableList<Korisnik> listNastavnik = FXCollections.observableArrayList();
    ObservableList<String> listVrsta = FXCollections.observableArrayList();
    ObservableList<Predmet> listTrazeniPredmeti = FXCollections.observableArrayList();
    ObservableList<Grupa> listTrazeneGrupe = FXCollections.observableArrayList();

    public void recieveInfoFromGrupe(Grupa grupa, int index, TableView<Grupa> table, ObservableList<Grupa> grList,  ObservableList<Predmet> prList,  ObservableList<String> vrList, ObservableList<Grupa> trList,  ObservableList<Korisnik> nList){
        selectedGrupa = grupa;
        selectedIndex = index;
        listGrupe = grList;
        listPredmeti = prList;
        listVrsta = vrList;
        listTrazeneGrupe = trList;
        listNastavnik=nList;

        colNazivPredmet.setCellValueFactory(new PropertyValueFactory<>("nazivPredmet"));
        tablePredmeti.setItems(listPredmeti);
        tablePredmeti.getSelectionModel().select(selectedGrupa.getPredmet());

        cbVrsta.setItems(listVrsta);
        String v = "";
        if(selectedGrupa.getVrsta().compareTo("P")==0) v="Predavanja";
        else if(selectedGrupa.getVrsta().compareTo("L")==0) v="Laboratorijske vježbe";
        else v="Auditorne vježbe";
        cbVrsta.getSelectionModel().select(v);
        lvNastavnik.setItems(listNastavnik);
        lvNastavnik.getSelectionModel().select(selectedGrupa.getNastavnik());
        etSifGrupa.setText(selectedGrupa.getSifraGrupa());

    }

    public void pretraziPredmeteClicked(){
        String pretraga = etPretraziPredmete.getText();
        if(etPretraziPredmete.getText().trim().isEmpty() || pretraga == null) {
            tablePredmeti.setItems(listPredmeti);
            return;
        }
        listTrazeniPredmeti.clear();
        try {
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM predmet WHERE nazivPredmet " +
                    "LIKE '%" + pretraga + "%'");
            while (rs.next()) {
                listTrazeniPredmeti.add(new Predmet(rs.getInt("idPredmet"), rs.getString("nazivPredmet"), rs.getString("sifraPredmet"),null,null));

            }
            rs.close();
            conn.close();
            tablePredmeti.setItems(listTrazeniPredmeti);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onPredmetClicked(MouseEvent e){
        if(e.isPrimaryButtonDown()){
            Predmet predmet = tablePredmeti.getSelectionModel().getSelectedItem();
            listNastavnik.clear();
            try{
                Connection conn = DBConnector.getConnection();
                ResultSet rs = conn.createStatement().executeQuery("SELECT idKorisnik,imeKorisnik,prezKorisnik FROM nastavnici " +
                        " INNER JOIN korisnik ON nastavnici.idNastavnik = korisnik.idKorisnik WHERE idPredmet = " + predmet.getIdPredmet());
                while(rs.next()) {
                    listNastavnik.add(new Korisnik(rs.getInt("idKorisnik"),null,null,rs.getString("imeKorisnik"),rs.getString("prezKorisnik"),false,false,false));
                }
                rs.close();
                conn.close();
            }
            catch (Exception err) {
                err.printStackTrace();
            }

        }
    }


    public void sacuvajClicked(){
        if(etSifGrupa.getText().trim().isEmpty()) {
            DBConnector.showAlert("Grupe", "Unesite sifru grupe!");
            etSifGrupa.requestFocus();
            return;
        }
        if(cbVrsta.getSelectionModel().getSelectedItem()==null){
            DBConnector.showAlert("Grupe", "Odaberite vrstu!");
            cbVrsta.requestFocus();
            return;
        }
        if(tablePredmeti.getSelectionModel().getSelectedItem()==null){
            DBConnector.showAlert("Grupe", "Odaberite predmet!");
            tablePredmeti.requestFocus();
            return;
        }
        if(lvNastavnik.getSelectionModel().getSelectedItem()==null){
            DBConnector.showAlert("Grupe", "Odaberite nastavnika!");
            lvNastavnik.requestFocus();
            return;
        }
        String sifGrupa = etSifGrupa.getText();
        String vrsta = cbVrsta.getSelectionModel().getSelectedItem();
        Predmet predmet = tablePredmeti.getSelectionModel().getSelectedItem();
        Korisnik nastavnik = lvNastavnik.getSelectionModel().getSelectedItem();
        if(sifGrupa.toLowerCase().compareTo(selectedGrupa.getSifraGrupa().toLowerCase()) != 0)
        for(Grupa e : listGrupe){
            if(sifGrupa.toLowerCase().compareTo(e.getSifraGrupa().toLowerCase())==0){
                DBConnector.showAlert("Grupe", "Grupa vec postoji!");
                return;
            }
        }
        if(vrsta.compareTo("Predavanja")==0) vrsta="P";
        else if(vrsta.compareTo("Auditorne vježbe")==0) vrsta="A";
        else vrsta="L";

        try{
            Connection conn = DBConnector.getConnection();
            String query = "UPDATE grupa SET idPredmet = ?, idNastavnik= ?, sifraGrupa= ?, vrsta = ? WHERE sifraGrupa = ? ";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, predmet.getIdPredmet());
            ps.setInt(2, nastavnik.getIdKorisnik());
            ps.setString(3, sifGrupa);
            ps.setString(4, vrsta);
            ps.setString(5, selectedGrupa.getSifraGrupa());
            if(ps.executeUpdate()>0) {
                DBConnector.showAlert("Grupe", "Unos uspjesan!");
                selectedGrupa.setPredmet(predmet);
                selectedGrupa.setNastavnik(nastavnik);
                selectedGrupa.setSifraGrupa(sifGrupa);
                selectedGrupa.setVrsta(vrsta);
                if(listTrazeneGrupe.isEmpty())
                listGrupe.set(selectedIndex,selectedGrupa);
                else
                    listTrazeneGrupe.set(selectedIndex,selectedGrupa);
                listNastavnik.clear();
                Stage stage = (Stage) etSifGrupa.getScene().getWindow();
                stage.close();
            }
            else {
                DBConnector.showAlert("Grupe", "Greska!");
                return;
            }
        }
        catch (Exception err) {
            err.printStackTrace();
        }

    }
}
