package main;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class saleController implements Initializable {

    @FXML
    private ComboBox<Zgrada> cbZgrada;
    @FXML
    private TableView<Sala> tableSale;
    @FXML
    private TableColumn<Sala, String> colSifSala;
    @FXML
    private TableColumn<Zgrada, String> colZgrada;
    @FXML
    private TextField etSifSale;

    ObservableList<Zgrada> zgradeList = FXCollections.observableArrayList();
    ObservableList<Sala> salaList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            Connection conn = DBConnector.getConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM sala INNER JOIN zgrada ON sala.idZgrada = zgrada.idZgrada");

            while (rs.next()) {
                Zgrada zgrada = new Zgrada(rs.getInt("idZgrada"), rs.getString("nazivZgrada"));
                salaList.add(new Sala(rs.getInt("idSala"),zgrada,rs.getString("sifraSala")));
            }

            rs = conn.createStatement().executeQuery("SELECT * FROM zgrada");
            while (rs.next()) {
                zgradeList.add(new Zgrada(rs.getInt("idZgrada"), rs.getString("nazivZgrada")));
            }

            rs.close();
            conn.close();

            colSifSala.setCellValueFactory(new PropertyValueFactory<>("sifraSala"));
            colZgrada.setCellValueFactory(new PropertyValueFactory<>("zgrada"));
            tableSale.setItems(salaList);
            cbZgrada.setItems(zgradeList);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dodajSaluClicked(){
        if(etSifSale.getText().trim().isEmpty()){
            DBConnector.showAlert("Sale","Molimo unesite sifru sale!");
            etSifSale.requestFocus();
            return;
        }
        if(cbZgrada.getSelectionModel().getSelectedItem()==null) {
            DBConnector.showAlert("Sale","Molimo izaberite zgradu!");
            cbZgrada.requestFocus();
            return;
        }
        String sifSala = etSifSale.getText();
        Zgrada zgrada = cbZgrada.getSelectionModel().getSelectedItem();
        for(Sala e : salaList){
            if((sifSala.compareTo(e.getSifraSala())) == 0 && zgrada.getIdZgrada() == e.getZgrada().getIdZgrada()){
                DBConnector.showAlert("Sale","Sala vec postoji!");
                return;
            }
        }


        try{
            Connection conn = DBConnector.getConnection();

            String query = "INSERT INTO sala (idZgrada, sifraSala) VALUES (?,?) ";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, zgrada.getIdZgrada());
            ps.setString(2,sifSala);
            if(ps.executeUpdate()>0) {
                DBConnector.showAlert("Sale", "Unos uspjesan");
                if(!salaList.isEmpty()){
                    int noviId = salaList.get(salaList.size()-1).getIdSala()+1;
                    salaList.add(new Sala(noviId,zgrada,sifSala));
                }
                else
                    salaList.add(new Sala(1,zgrada,sifSala));
                tableSale.refresh();
                conn.close();
                etSifSale.clear();
            }
            else {
                DBConnector.showAlert("Sale", "Greska!");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void obrisiClicked(){
        Sala odabranaSala = tableSale.getSelectionModel().getSelectedItem();
        if(odabranaSala == null) {
            DBConnector.showAlert("Sale", "Molimo odaberite salu");
            return;
        }
        int selectedIndex = tableSale.getSelectionModel().getFocusedIndex();

        try{
            if(zadnjiIzabran(odabranaSala)){
                Connection conn = DBConnector.getConnection();
                String query = "DELETE FROM sala WHERE idSala = ? ";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setInt(1, odabranaSala.getIdSala());
                if(ps.executeUpdate()>0) {
                    salaList.remove(selectedIndex);
                    PreparedStatement preparedStatement = conn.prepareStatement("ALTER TABLE sala AUTO_INCREMENT = ?");
                    if(salaList.size() > 1)
                        preparedStatement.setInt(1,salaList.get(salaList.size()-1).getIdSala());
                    else
                        preparedStatement.setInt(1, 1);
                    preparedStatement.executeUpdate();
                    DBConnector.showAlert("Sale", "Brisanje uspjesno");
                    tableSale.refresh();
                }
                else {
                    DBConnector.showAlert("Sale", "Greska!");
                }
                conn.close();

            }
            else {
                Connection conn = DBConnector.getConnection();
                String query = "DELETE FROM sala WHERE idSala = ? ";
                PreparedStatement ps = conn.prepareStatement(query);
                ps.setInt(1, odabranaSala.getIdSala());
                if(ps.executeUpdate()>0) {
                    DBConnector.showAlert("Sale", "Brisanje uspjesno");
                    salaList.remove(selectedIndex);
                    tableSale.refresh();
                }
                else {
                    DBConnector.showAlert("Sale", "Greska!");
                }
                conn.close();
            }

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void urediSaleClicked() throws IOException{
       Sala selectedSala = tableSale.getSelectionModel().getSelectedItem();
        int selectedIndex = tableSale.getSelectionModel().getFocusedIndex();
        if(selectedSala == null) {
            DBConnector.showAlert("Sale", "Molimo izaberite salu!");
            return;
        }
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("saleUredi.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        urediSaleController urediController = fxmlLoader.getController();
        urediController.recieveInfoFromSale(selectedSala,selectedIndex,zgradeList,salaList,tableSale);
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Uredi salu");
        stage.setResizable(false);
        stage.setScene(new Scene(root1));
        stage.show();

    }



    public void btnNazadClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("prodekan.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    private boolean zadnjiIzabran(Sala sala){
        return sala.getIdSala() == salaList.get(salaList.size()-1).getIdSala();
    }

}
