package main;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class ProdekanController {

    private static Korisnik prodekan;

    @FXML
    Button btnZgrade;

    public void recieveInfoFromLogin(Korisnik prodekan){
        this.prodekan = prodekan;
    }

    public void btnZgradeClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("zgrade.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan - Zgrade");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    public void btnSaleClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("sale.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan - Sale");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    public void btnUsmjerenjaClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("usmjerenja.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan - Usmjerenja");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    public void btnPredmetiClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("predmeti.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan - predmeti");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    public void btnGrupeClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("grupe.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan - grupe");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    public void odjavaClicked(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan - grupe");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    public void btnRezervacijeClicked(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("rezervacije.fxml"));
        Parent root = loader.load();
        RezervacijeController controller = loader.getController();
        controller.recieveInfoFromLogin(prodekan);
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Prodekan - rezervacije");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    @FXML
    public void rasporedButtonClicked(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("raspored.fxml"));
        Parent root = loader.load();
        RasporedController controller = loader.getController();
        controller.receiveInfofromKorisnik(prodekan);
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setTitle("Raspored");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }


}
