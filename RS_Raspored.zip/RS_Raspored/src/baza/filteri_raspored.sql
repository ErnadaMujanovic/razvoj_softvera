-- po zgradi --
SELECT datum, pocetak, kraj, tip, sifraSala, imeKorisnik, prezKorisnik, nazivZgrada, nazivPredmet FROM rezervacija
INNER JOIN grupa
ON rezervacija.idGrupa = grupa.idGrupa
INNER JOIN predmet
ON grupa.idPredmet = predmet.idPredmet
INNER JOIN korisnik
ON rezervacija.idKorisnik = korisnik.idKorisnik
INNER JOIN sala 
ON rezervacija.idSala = sala.idSala
INNER JOIN zgrada
ON sala.idZgrada = zgrada.idZgrada
WHERE nazivZgrada = "GIM"

-- po rezervatoru --
SELECT datum, pocetak, kraj, tip, sifraSala, imeKorisnik, prezKorisnik, nazivZgrada, nazivPredmet FROM rezervacija
INNER JOIN grupa 
ON rezervacija.idGrupa = grupa.idGrupa
INNER JOIN predmet
ON grupa.idPredmet = predmet.idPredmet
INNER JOIN korisnik
ON rezervacija.idKorisnik = korisnik.idKorisnik
INNER JOIN sala 
ON rezervacija.idSala = sala.idSala
INNER JOIN zgrada
ON sala.idZgrada = zgrada.idZgrada
WHERE imeKorisnik = "Emir" AND prezKorisnik = "Nukic";

-- po predmetu -- 
SELECT datum, pocetak, kraj, tip, sifraSala, imeKorisnik, prezKorisnik, nazivZgrada, nazivPredmet FROM rezervacija
INNER JOIN grupa 
ON rezervacija.idGrupa = grupa.idGrupa
INNER JOIN predmet
ON grupa.idPredmet = predmet.idPredmet
INNER JOIN korisnik
ON rezervacija.idKorisnik = korisnik.idKorisnik
INNER JOIN sala 
ON rezervacija.idSala = sala.idSala
INNER JOIN zgrada
ON sala.idZgrada = zgrada.idZgrada
WHERE nazivPredmet = "Racunarske mreze";
