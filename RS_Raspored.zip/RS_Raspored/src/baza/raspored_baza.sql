DROP DATABASE raspored;
CREATE DATABASE raspored;
USE raspored;

CREATE TABLE IF NOT EXISTS semestar (
  idSemestar	INT				NOT NULL	AUTO_INCREMENT
, pocetak		DATE			NOT NULL
, kraj			DATE			NOT NULL
, nazivSemestar 	VARCHAR(10)		NOT NULL
, PRIMARY KEY (idSemestar)
);

CREATE TABLE IF NOT EXISTS korisnik (
  idKorisnik 	INT 			NOT NULL	AUTO_INCREMENT
, korIme 		VARCHAR(45) 	NOT NULL	
, korSifra 		VARCHAR(45) 	NOT NULL
, imeKorisnik 	VARCHAR(45)   	NOT NULL
, prezKorisnik 	VARCHAR(45)		NOT NULL
, prodekan 		BOOL 			NOT NULL
, profesor 		BOOL			NOT NULL
, saradnik		bool			NOT NULL
, PRIMARY KEY (idKorisnik)
);


CREATE TABLE IF NOT EXISTS predmet (
  idPredmet 		INT 			NOT NULL	AUTO_INCREMENT	
, nazivPredmet 		VARCHAR(45) 	NOT NULL	
, sifraPredmet		VARCHAR(10)		NOT NULL	
, idNosioc 			INT 			
, idSemestar 		INT				NOT NULL
, PRIMARY KEY (idPredmet)
, FOREIGN KEY (idNosioc) REFERENCES korisnik(idKorisnik) 
, FOREIGN KEY (idSemestar) REFERENCES semestar(idSemestar) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS grupa (
  idGrupa 		INT 		NOT NULL 	AUTO_INCREMENT
, idPredmet 	INT 		NOT NULL
, idNastavnik 	INT 		NOT NULL
, sifraGrupa    VARCHAR(20) NOT NULL
, vrsta 		VARCHAR(2)	NOT NULL
, PRIMARY KEY (idGrupa)
, FOREIGN KEY (idPredmet) REFERENCES predmet(idPredmet) ON DELETE CASCADE ON UPDATE CASCADE
, FOREIGN KEY (idNastavnik) REFERENCES korisnik(idKorisnik) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS usmjerenje (
  idUsmjerenje 		INT			 	NOT NULL	AUTO_INCREMENT
, sifraUsmjerenje	VARCHAR(4)		NOT NULL 	
, nazivUsmjerenje 	VARCHAR(45) 	NOT NULL	
, PRIMARY KEY (idUsmjerenje)
);


CREATE TABLE IF NOT EXISTS zgrada (
  idZgrada 		INT 			NOT NULL 	AUTO_INCREMENT
, nazivZgrada 	VARCHAR(45) 	NOT NULL	
, PRIMARY KEY (idZgrada)
);


CREATE TABLE IF NOT EXISTS sala (
  idSala 		INT 			NOT NULL	AUTO_INCREMENT
, idZgrada 		INT 			NOT NULL
, sifraSala 	VARCHAR(45) 	NOT NULL	
, PRIMARY KEY (idSala)
, FOREIGN KEY (idZgrada) REFERENCES zgrada(idZgrada) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS rezervacija (
  idRezervacija 	INT 			NOT NULL 	AUTO_INCREMENT
, datum 			DATE			NOT NULL
, pocetak 			TIME 			NOT NULL
, kraj 				TIME 			NOT NULL
, tip 				VARCHAR(20)		NOT NULL
, idSala 			INT 			NOT NULL
, idKorisnik 		INT 			NOT NULL
, idGrupa			INT							
, PRIMARY KEY (idRezervacija)
, FOREIGN KEY(idSala) REFERENCES sala(idSala) ON DELETE CASCADE ON UPDATE CASCADE
, FOREIGN KEY(idKorisnik) REFERENCES korisnik(idKorisnik) ON DELETE CASCADE ON UPDATE CASCADE
, FOREIGN KEY(idGrupa) REFERENCES grupa(idGrupa) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS predmeti (
  idPredmet 		INT 	NOT NULL
, idUsmjerenje 		INT 	NOT NULL
, godinaStudija		INT		NOT NULL
, PRIMARY KEY (idPredmet, idUsmjerenje, godinaStudija)
, FOREIGN KEY (idPredmet) REFERENCES predmet(idPredmet) ON DELETE CASCADE ON UPDATE CASCADE
, FOREIGN KEY (idUsmjerenje) REFERENCES usmjerenje(idUsmjerenje) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS nastavnici (
  idPredmet 	INT 	NOT NULL
, idNastavnik 	INT 	NOT NULL
, PRIMARY KEY (idPredmet, idNastavnik)
, FOREIGN KEY (idPredmet) REFERENCES predmet(idPredmet) ON DELETE CASCADE ON UPDATE CASCADE
, FOREIGN KEY (idNastavnik) REFERENCES korisnik(idKorisnik) ON DELETE CASCADE ON UPDATE CASCADE
);
