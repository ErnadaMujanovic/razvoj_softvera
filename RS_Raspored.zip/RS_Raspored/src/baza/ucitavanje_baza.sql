LOAD DATA LOCAL INFILE '/home/adin/rs_raspored/baza/CSV/semestar.csv' 
INTO TABLE semestar
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n';


LOAD DATA LOCAL INFILE '/home/adin/rs_raspored/baza/CSV/zgrada.csv' 
INTO TABLE zgrada 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n';


LOAD DATA LOCAL INFILE '/home/adin/rs_raspored/baza/CSV/sala.csv' 
INTO TABLE sala 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n';


LOAD DATA LOCAL INFILE '/home/adin/rs_raspored/baza/CSV/usmjerenje.csv' 
INTO TABLE usmjerenje 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n';


LOAD DATA LOCAL INFILE '/home/adin/rs_raspored/baza/CSV/korisnik.csv' 
INTO TABLE korisnik 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n';


LOAD DATA LOCAL INFILE '/home/adin/rs_raspored/baza/CSV/predmet.csv' 
INTO TABLE predmet 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n';


LOAD DATA LOCAL INFILE '/home/adin/rs_raspored/baza/CSV/grupa.csv' 
INTO TABLE grupa 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n';


LOAD DATA LOCAL INFILE '/home/adin/rs_raspored/baza/CSV/predmeti.csv' 
INTO TABLE predmeti 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n';


LOAD DATA LOCAL INFILE '/home/adin/rs_raspored/baza/CSV/nastavnici.csv' 
INTO TABLE nastavnici
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n';


LOAD DATA LOCAL INFILE '/home/adin/rs_raspored/baza/CSV/rezervacija.csv' 
INTO TABLE rezervacija 
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n';


SELECT * FROM semestar;
SELECT * FROM zgrada;
SELECT * FROM sala;
SELECT * FROM usmjerenje;
SELECT * FROM korisnik;
SELECT * FROM predmet;
SELECT * FROM grupa;
SELECT * FROM predmeti;
SELECT * FROM nastavnici;
SELECT * FROM rezervacija;